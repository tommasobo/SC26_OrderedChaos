#!/usr/bin/env python3
import argparse
import subprocess
import sys
import shutil
import signal
from pathlib import Path
from dataclasses import dataclass, field
from typing import List
import concurrent.futures

# Color + logging helpers
COLOR_RESET = "\033[0m"
COLOR_GREEN = "\033[32m"
COLOR_RED = "\033[31m"
COLOR_CYAN = "\033[36m"
COLOR_YELLOW = "\033[33m"
COLOR_BOLD = "\033[1m"
VERBOSE = False
EXTRA_VERBOSE = False

MTU_SIZE = 4160  # MTU size in bytes
ACK_SIZE = 64  # ACK packet size in bytes
ECN_MIN_PERCENTAGE = 0.2  # Minimum ECN marking percentage
ECN_MAX_PERCENTAGE = 0.8  # Maximum ECN marking percentage
CONFIG = ["rss", "reps", "ecmp", "oblivious", "flowbender", "flowlet"]
EXTRA_CONFIG = ["rss1", "rss2"]
DROP_CONFIG = [0, 0.0005]
TRIM_CONFIG = [True, False]  # True => trimming ON (no -disable_trim), False => trimming OFF (add -disable_trim)

def _log(msg, color=COLOR_CYAN, force=False, stream=sys.stdout):
    if not VERBOSE and not force:
        return
    print(f"{color}{msg}{COLOR_RESET}", file=stream)

def addExtra(name):
    if name == "rss1":
        return [
            "-precisefastlossrecovery", "3",
            "-pflr_proactive_probe", "0",
            "-pflr_proactive_rtx_probe",
            "-no_droping_low_header",
        ]
    if name == "rss2":
        return [
            "-precisefastlossrecovery", "3",
            "-pflr_proactive_probe", "16",
            "-pflr_proactive_rtx_probe",
            "-no_droping_low_header",
        ]
    return []

def getBDP(linkspeed, delay):
    # linkspeed in Mbps, delay in nanoseconds
    linkspeed_gbps = linkspeed / 1000  # Convert Mbps to Gbps
    total_delay = 4 * 2 * delay  # hops, round-trip time, delay value
    total_transmission_time = (MTU_SIZE*8/linkspeed_gbps*4)+(ACK_SIZE*8/linkspeed_gbps*4)
    total_delay += total_transmission_time
    bdp_bytes = linkspeed_gbps * total_delay / 8  # Convert Mbps to bytes per second
    return int(bdp_bytes)

def getTopo(size, linkspeed):
    if size == 64:
        return "/home/tbonato/msft-htsim/scripts/topologies/64_{}.topo".format(int(linkspeed/1000)) 
    elif size == 128:
        return "/home/tbonato/msft-htsim/scripts/topologies/128_{}.topo".format(int(linkspeed/1000))
    elif size == 1024:
        return "/home/tbonato/msft-htsim/scripts/topologies/1024_{}.topo".format(int(linkspeed/1000))
    elif size == 16:
        return "/home/tbonato/msft-htsim/scripts/topologies/16_{}.topo".format(int(linkspeed/1000))
    else:
        raise ValueError(f"Unsupported topology size: {size}")

def build_command(arguments, algo, drop_prob, trim_on, seed, extra_args=None):
    # Build simulation command (no binary metrics output requested)
    bdp = getBDP(arguments.linkspeed, arguments.delay)
    bdp_packets = int(bdp / MTU_SIZE)
    topology_path = getTopo(arguments.topo_size, arguments.linkspeed)
    command = [
        "/home/tbonato/msft-htsim/build/htsim_uec",
        "-data_collection_config", "/home/tbonato/msft-htsim/scripts/metrics_collection_policies/collect_default.json",
        "-end", "10000", "-seed", str(seed),
    ]
    if arguments.goal:
        command += ["-goal", f"/home/tbonato/msft-htsim/sim/lgs/{arguments.goal}"]
    else:
        command += ["-tm", f"/home/tbonato/msft-htsim/scripts/connection_matrices/{arguments.tm}"]
    command += [
        "-topo", topology_path,
        "-q", str(bdp_packets), "-cwnd", str(bdp_packets), "-mtu", "4160",
        "-sack_threshold", "0",
        "-ecn", str(int(bdp_packets*ECN_MIN_PERCENTAGE)), str(int(bdp_packets*ECN_MAX_PERCENTAGE)),
        "-switch_random_drop_prob", str(drop_prob),
        "-fail_psn", "-1",
        "-rto_ratio", "2",
        "-load_balancing_algo", algo,
        "-linkspeed", str(arguments.linkspeed),
        "-rss_parameters", "mean_rtt", "16", "50", "0", "0", "25",
        "-sender_cc_only", "-sender_cc_algo", "dctcp",
        "-data_collection_dir", str(arguments.out_dir),
        "-nodes", str(arguments.topo_size),
        "-lgs_percent", str(arguments.lgs_percentage),
    ]
    if not trim_on:
        command.append("-disable_trim")
    command += getAlgoSpecificArgs(algo)
    if extra_args:
        command += extra_args
    return command

def getAlgoSpecificArgs(algo):
    if algo == "rss":
        return []  # Already included in base command
    elif algo == "reps":
        return []
    elif algo == "ecmp":
        return []
    return []
    """ else:
        raise ValueError(f"Unknown algorithm: {algo}") """

def run_algo(algo, drop_prob, trim_on, seed, args, log_file, extra_args=None):
    cmd = build_command(args, algo, drop_prob, trim_on, seed, extra_args)
    trim_tag = "trim_on" if trim_on else "trim_off"
    tag = f"{algo} {trim_tag} seed={seed} drop={drop_prob}" + (" extra" if extra_args else "")
    if EXTRA_VERBOSE:
        # Print the full command line being executed.
        print(f"{COLOR_YELLOW}CMD   {tag}: {' '.join(cmd)}{COLOR_RESET}")
    _log(f"START {tag}", COLOR_CYAN)
    with open(log_file, "w") as lf:
        proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT)
        rc = proc.wait()
    if rc != 0:
        _log(f"FAIL  {tag} (rc={rc})", COLOR_RED, force=True, stream=sys.stderr)
        raise RuntimeError(f"{tag} exited with code {rc}")
    _log(f"DONE  {tag}", COLOR_GREEN)
    return rc

def main():
    ap = argparse.ArgumentParser(
        description="Run htsim_uec for all algorithms x drop probabilities (baseline + variants)."
    )
    ap.add_argument("--file_name", default="study",
                    help="(Legacy/unused) Base name placeholder kept for compatibility.")
    ap.add_argument("--lgs_percentage", type=int, default=10,
                    help="Percentage of large flows (LGS) in the workload (integer).")
    ap.add_argument("--linkspeed", type=int, default=100000,
                    help="Link speed in Mbps (e.g. 100000 = 100 Gbps).")
    ap.add_argument("--delay", type=int, default=100000,
                    help="One-way propagation delay per hop in nanoseconds.")
    ap.add_argument("--topo_size", type=int, default=64, choices=[64, 128, 16, 1024],
                    help="Topology size (number of hosts).")
    ap.add_argument("--workers", type=int, default=4,
                    help="Maximum number of simulations to run concurrently.")
    ap.add_argument("--goal", default=None,
                    help="Goal file name located under scripts/goals/. (Mutually exclusive with --tm)")
    ap.add_argument("--tm", default=None,
                    help="Traffic matrix file name located under scripts/goals/. (Mutually exclusive with --goal)")
    ap.add_argument("--out_dir", default="experiment1",
                    help="Experiment name subdirectory (created under nsdi_results/).")
    ap.add_argument("--verbose", action="store_true",
                    help="Enable detailed per-run logging.")
    ap.add_argument("--extra-verbose", action="store_true",
                    help="Also print the full simulation command lines.")
    ap.add_argument("--clean", action="store_true",
                    help="Delete existing contents of the output experiment directory before running.")
    ap.add_argument("--seeds", type=int, default=1,
                    help="Number of different seeds to run (seeds are 1..N).")
    args = ap.parse_args()

    # Validate mutually exclusive --goal / --tm
    if args.goal and args.tm:
        ap.error("Cannot specify both --goal and --tm. Choose exactly one.")
    if not args.goal and not args.tm:
        ap.error("You must specify exactly one of --goal or --tm.")

    global VERBOSE, EXTRA_VERBOSE
    VERBOSE = args.verbose
    EXTRA_VERBOSE = args.extra_verbose

    # Root results directory + experiment subdirectory
    root_dir = Path("nsdi_results")
    root_dir.mkdir(parents=True, exist_ok=True)
    exp_dir = root_dir / args.out_dir
    # If cleaning requested and directory exists, remove its contents (but keep directory itself)
    if args.clean and exp_dir.exists():
        _log(f"Cleaning existing contents of {exp_dir} ...", COLOR_YELLOW, force=True)
        for item in exp_dir.iterdir():
            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
            except Exception as e:
                _log(f"Failed to remove {item}: {e}", COLOR_RED, force=True, stream=sys.stderr)
    exp_dir.mkdir(parents=True, exist_ok=True)

    # Mutate args so build_command uses the full path for data collection dir
    args.out_dir = str(exp_dir)

    results = {}

    # For each drop probability, create drop subfolder and run all algorithms + variants
    _log("Running experiments across drop probabilities and trim settings...", COLOR_BOLD if VERBOSE else COLOR_CYAN, force=VERBOSE)
    drop_tasks = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        for seed in range(1, args.seeds + 1):
            for dp in DROP_CONFIG:
                dp_dir = exp_dir / f"drop_{dp}"
                dp_dir.mkdir(parents=True, exist_ok=True)
                for trim_on in TRIM_CONFIG:
                    trim_suffix = "trim_on" if trim_on else "trim_off"
                    for algo in CONFIG:
                        log_file = dp_dir / f"{algo}_seed{seed}_{trim_suffix}.txt"
                        fut = executor.submit(run_algo, algo, dp, trim_on, seed, args, log_file)
                        drop_tasks.append((fut, algo, dp, trim_on, seed))
                    for variant in EXTRA_CONFIG:
                        extra_args = addExtra(variant)
                        log_file = dp_dir / f"{variant}_seed{seed}_{trim_suffix}.txt"
                        fut = executor.submit(run_algo, "rss", dp, trim_on, seed, args, log_file, extra_args)
                        drop_tasks.append((fut, variant, dp, trim_on, seed))
        for fut, algo, dp, trim_on, seed in drop_tasks:
            try:
                fut.result()
                results[(algo, dp, trim_on, seed)] = "ok"
            except Exception as e:
                results[(algo, dp, trim_on, seed)] = f"failed: {e}"

    # Summary (always printed)
    print(f"{COLOR_BOLD}Summary:{COLOR_RESET}")
    for (algo, dp, trim_on, seed), status in results.items():
        color = COLOR_GREEN if status == "ok" else COLOR_RED
        trim_suffix = "trim_on" if trim_on else "trim_off"
        print(f"{color}{algo:<8} drop={dp:<8} {trim_suffix:<8} seed={seed:<3} {status}{COLOR_RESET}")

if __name__ == "__main__":
    main()
