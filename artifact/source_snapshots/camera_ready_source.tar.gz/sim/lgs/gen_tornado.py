#!/usr/bin/env python3
import argparse
import sys

def generate_goal(num_ranks: int, msg_bytes: int, tag: int = 0, include_recvs: bool = True):
    if num_ranks % 2 != 0:
        raise ValueError("num_ranks must be even for a tornado pattern (uses N/2 offset).")
    offset = num_ranks // 2

    out = []
    out.append(f"num_ranks {num_ranks}\n")
    for r in range(num_ranks):
        dst = (r + offset) % num_ranks
        src = (r - offset) % num_ranks
        out.append(f"rank {r} {{")
        out.append(f"l1: send {msg_bytes}b to {dst} tag {tag}")
        if include_recvs:
            out.append(f"l2: recv {msg_bytes}b from {src} tag {tag}")
        out.append("}\n")
    sys.stdout.write("\n".join(out))

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Generate GOAL-format tornado traffic.")
    p.add_argument("--nodes", type=int, default=64, help="Number of ranks (must be even).")
    size = p.add_mutually_exclusive_group()
    size.add_argument("--msg-bytes", type=int, help="Message size in bytes (e.g., 1000000).")
    size.add_argument("--msg-mb", type=float, default=1.0, help="Message size in MB (decimal, default 1.0).")
    p.add_argument("--tag", type=int, default=0, help="GOAL message tag (default 0).")
    p.add_argument("--no-recvs", action="store_true", help="Omit explicit recv lines.")
    args = p.parse_args()

    msg_b = args.msg_bytes if args.msg_bytes is not None else int(args.msg_mb * 1_000_000)
    generate_goal(args.nodes, msg_b, tag=args.tag, include_recvs=not args.no_recvs)
