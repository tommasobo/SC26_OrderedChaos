// -*- c-basic-offset: 4; indent-tabs-mode: nil -*-
// #include "types.h"
#include <math.h>
#include <string.h>
#include <unistd.h>

#include <list>
#include <sstream>

#include "clock.h"
#include "compositequeue.h"
#include "connection_matrix.h"
#include "eqds.h"
#include "eqds_logger.h"
#include "event_source.h"
#include "eventlist.h"
#include "fat_tree_switch.h"
#include "fat_tree_topology.h"
#include "helpers.h"
#include "logfile.h"
#include "packet.h"
#include "packet_flow.h"
#include "pipe.h"
#include "topology.h"

// Simulation params

// #define PRINTPATHS 1

#include "topology.h"

int DEFAULT_NODES = 128;
#define DEFAULT_QUEUE_SIZE 35
#define DEFAULT_CWND 64

EventList& eventlist = EventList::getTheEventList();

void exit_error(char* progr) {
    cout << "Usage " << progr
         << " [-nodes N]\n\t[-conns C]\n\t[-cwnd cwnd_size]\n\t[-q "
            "queue_size]\n\t[-recv_oversub_cc] Use receiver-driven AIMD to reduce total window "
            "when trims are not last hop\n\t[-queue_type "
            "composite|random|lossless|lossless_input|]\n\t[-tm traffic_matrix_file]\n\t[-strat "
            "route_strategy (single,rand,perm,pull,ecmp,\n\tecmp_host "
            "path_count,ecmp_ar,ecmp_rr,\n\tecmp_host_ar ar_thresh)]\n\t[-log log_level]\n\t[-seed "
            "random_seed]\n\t[-end end_time_in_usec]\n\t[-mtu MTU]\n\t[-hop_latency x] per hop "
            "wire latency in us,default 1\n\t[-switch_latency x] switching latency in us, default "
            "0\n\t[-host_queue_type  swift|prio|fair_prio]\n\t[-logtime dt] sample time for "
            "sinklogger, etc"
         << endl;
    exit(1);
}

int main(int argc, char** argv) {
    Clock           c(timeFromSec(5 / 100.), eventlist);
    mem_b           queuesize         = DEFAULT_QUEUE_SIZE;
    linkspeed_bps   linkspeed         = speedFromMbps((double)HOST_NIC);
    int             packet_size       = 4150;
    uint32_t        path_entropy_size = 64;
    uint32_t        no_of_conns = 0, cwnd = DEFAULT_CWND, no_of_nodes = 0;
    uint32_t        tiers    = 3;                 // we support 2 and 3 tier fattrees
    uint32_t        planes   = 1;                 // multi-plane topologies
    uint32_t        ports    = 1;                 // ports per NIC
    uint16_t        trimsize = 64;                // size of a trimmed packet
    simtime_picosec logtime  = timeFromMs(0.25);  // ms;
    stringstream    filename(ios_base::out);
    simtime_picosec hop_latency    = timeFromUs((uint32_t)1);
    simtime_picosec switch_latency = timeFromUs((uint32_t)0);
    queue_type      qt             = COMPOSITE;

    bool log_sink        = false;
    bool log_nic         = false;
    bool log_flow_events = true;

    bool   log_tor_downqueue = false;
    bool   log_tor_upqueue   = false;
    bool   log_traffic       = false;
    bool   log_switches      = false;
    bool   log_queue_usage   = false;
    double ecn_thresh        = 0.5;  // default marking threshold for ECN load balancing

    bool  ecn     = false;
    mem_b ecn_low = 0, ecn_high = 0;

    bool receiver_driven = true;

    RouteStrategy route_strategy = NOT_SET;

    int seed       = 13;
    int path_burst = 1;
    int i          = 1;

    bool use_exp_avg_rtt = false;
    bool use_exp_avg_ecn = false;
    bool use_reps        = false;

    bool receiver_oversubscribed_cc = false;

    filename << "logout.dat";
    int end_time = 1000;  // in microseconds

    // unsure how to set this.
    queue_type snd_type = FAIR_PRIO;

    float                         ar_sticky_delta = 10;
    FatTreeSwitch::sticky_choices ar_sticky       = FatTreeSwitch::PER_PACKET;

    char* tm_file   = NULL;
    char* topo_file = NULL;

    while (i < argc) {
        if (!strcmp(argv[i], "-o")) {
            filename.str(std::string());
            filename << argv[i + 1];
            i++;
        } else if (!strcmp(argv[i], "-recv_oversub_cc")) {
            receiver_oversubscribed_cc = true;
        } else if (!strcmp(argv[i], "-conns")) {
            no_of_conns = atoi(argv[i + 1]);
            cout << "no_of_conns " << no_of_conns << endl;
            i++;
        } else if (!strcmp(argv[i], "-end")) {
            end_time = atoi(argv[i + 1]);
            cout << "endtime(us) " << end_time << endl;
            i++;
        } else if (!strcmp(argv[i], "-nodes")) {
            no_of_nodes = atoi(argv[i + 1]);
            cout << "no_of_nodes " << no_of_nodes << endl;
            i++;
        } else if (!strcmp(argv[i], "-tiers")) {
            tiers = atoi(argv[i + 1]);
            cout << "tiers " << tiers << endl;
            assert(tiers == 2 || tiers == 3);
            i++;
        } else if (!strcmp(argv[i], "-use_exp_avg_ecn")) {
            use_exp_avg_ecn = atoi(argv[i + 1]);
            printf("UseExpAvgEcn: %d\n", use_exp_avg_ecn);
            EqdsSrc::set_exp_avg_ecn(use_exp_avg_ecn);
            i++;
        } else if (!strcmp(argv[i], "-use_exp_avg_rtt")) {
            use_exp_avg_rtt = atoi(argv[i + 1]);
            printf("UseExpAvgRtt: %d\n", use_exp_avg_rtt);
            EqdsSrc::set_exp_avg_rtt(use_exp_avg_rtt);

        } else if (!strcmp(argv[i], "-use_reps")) {
            use_reps = atoi(argv[i + 1]);
            printf("UseREPS: %d\n", use_reps);
            EqdsSrc::set_reps(use_reps);
            i++;
        } else if (!strcmp(argv[i], "-planes")) {
            planes = atoi(argv[i + 1]);
            ports  = planes;
            cout << "planes " << planes << endl;
            cout << "ports per NIC " << ports << endl;
            assert(planes >= 1 && planes <= 8);
            i++;
        } else if (!strcmp(argv[i], "-sender_cc_only")) {
            EqdsSrc::_sender_based_cc = true;
            receiver_driven           = false;
            cout << "sender based CC enabled ONLY" << endl;

        } else if (!strcmp(argv[i], "-sender_cc_algo")) {
            EqdsSrc::_sender_based_cc = true;

            if (!strcmp(argv[i + 1], "dctcp"))
                EqdsSrc::_sender_cc_algo = EqdsSrc::DCTCP;
            else {
                cout << "UNKNOWN CC ALGO " << argv[i + 1] << endl;
                exit(1);
            }
            cout << "sender based algo " << argv[i + 1] << endl;
            i++;
        } else if (!strcmp(argv[i], "-sender_cc")) {
            EqdsSrc::_sender_based_cc = true;
            cout << "sender based CC enabled " << tiers << endl;
        } else if (!strcmp(argv[i], "-queue_type")) {
            if (!strcmp(argv[i + 1], "composite")) {
                qt = COMPOSITE;
            } else if (!strcmp(argv[i + 1], "composite_ecn")) {
                qt = COMPOSITE_ECN;
            } else if (!strcmp(argv[i + 1], "aeolus")) {
                qt = AEOLUS;
            } else if (!strcmp(argv[i + 1], "aeolus_ecn")) {
                qt = AEOLUS_ECN;
            } else {
                cout << "Unknown queue type " << argv[i + 1] << endl;
                exit_error(argv[0]);
            }
            cout << "queue_type " << qt << endl;
            i++;
        } else if (!strcmp(argv[i], "-debug")) {
            EqdsSrc::_debug = true;
        } else if (!strcmp(argv[i], "-host_queue_type")) {
            if (!strcmp(argv[i + 1], "swift")) {
                snd_type = SWIFT_SCHEDULER;
            } else if (!strcmp(argv[i + 1], "prio")) {
                snd_type = PRIORITY;
            } else if (!strcmp(argv[i + 1], "fair_prio")) {
                snd_type = FAIR_PRIO;
            } else {
                cout << "Unknown host queue type " << argv[i + 1]
                     << " expecting one of swift|prio|fair_prio" << endl;
                exit_error(argv[0]);
            }
            cout << "host queue_type " << snd_type << endl;
            i++;
        } else if (!strcmp(argv[i], "-log")) {
            if (!strcmp(argv[i + 1], "flow_events")) {
                log_flow_events = true;
            } else if (!strcmp(argv[i + 1], "sink")) {
                cout << "logging sinks\n";
                log_sink = true;
            } else if (!strcmp(argv[i + 1], "nic")) {
                cout << "logging nics\n";
                log_nic = true;
            } else if (!strcmp(argv[i + 1], "tor_downqueue")) {
                cout << "logging tor downqueues\n";
                log_tor_downqueue = true;
            } else if (!strcmp(argv[i + 1], "tor_upqueue")) {
                cout << "logging tor upqueues\n";
                log_tor_upqueue = true;
            } else if (!strcmp(argv[i + 1], "switch")) {
                cout << "logging total switch queues\n";
                log_switches = true;
            } else if (!strcmp(argv[i + 1], "traffic")) {
                cout << "logging traffic\n";
                log_traffic = true;
            } else if (!strcmp(argv[i + 1], "queue_usage")) {
                cout << "logging queue usage\n";
                log_queue_usage = true;
            } else {
                exit_error(argv[0]);
            }
            i++;
        } else if (!strcmp(argv[i], "-cwnd")) {
            cwnd = atoi(argv[i + 1]);
            cout << "cwnd " << cwnd << endl;
            i++;
        } else if (!strcmp(argv[i], "-tm")) {
            tm_file = argv[i + 1];
            cout << "traffic matrix input file: " << tm_file << endl;
            i++;
        } else if (!strcmp(argv[i], "-topo")) {
            topo_file = argv[i + 1];
            cout << "FatTree topology input file: " << topo_file << endl;
            i++;
        } else if (!strcmp(argv[i], "-q")) {
            queuesize = atoi(argv[i + 1]);
            i++;
        } /* else if (!strcmp(argv[i],"-pci")){
             EqdsSink::_modelPCIbandwidth = true;
         }
         else if (!strcmp(argv[i],"-ecn_thresh")){
             // fraction of queuesize, between 0 and 1
             ecn_thresh = atof(argv[i+1]);
             i++;
         }*/
        else if (!strcmp(argv[i], "-ecn")) {
            // fraction of queuesize, between 0 and 1
            ecn      = true;
            ecn_low  = atoi(argv[i + 1]);
            ecn_high = atoi(argv[i + 2]);
            i += 2;
        } else if (!strcmp(argv[i], "-trimsize")) {
            // size of trimmed packet in bytes
            trimsize = atoi(argv[i + 1]);
            cout << "trimmed packet size: " << trimsize << " bytes\n";
            i += 1;
        } else if (!strcmp(argv[i], "-logtime")) {
            double log_ms = atof(argv[i + 1]);
            logtime       = timeFromMs(log_ms);
            cout << "logtime " << logtime << " ms" << endl;
            i++;
        } else if (!strcmp(argv[i], "-linkspeed")) {
            // linkspeed specified is in Mbps
            linkspeed = speedFromMbps(atof(argv[i + 1]));
            i++;
        } else if (!strcmp(argv[i], "-seed")) {
            seed = atoi(argv[i + 1]);
            cout << "random seed " << seed << endl;
            i++;
        } else if (!strcmp(argv[i], "-mtu")) {
            packet_size = atoi(argv[i + 1]);
            i++;
        } else if (!strcmp(argv[i], "-paths")) {
            path_entropy_size = atoi(argv[i + 1]);
            cout << "no of paths " << path_entropy_size << endl;
            i++;
        } else if (!strcmp(argv[i], "-path_burst")) {
            path_burst = atoi(argv[i + 1]);
            cout << "path burst " << path_burst << endl;
            i++;
        } else if (!strcmp(argv[i], "-hop_latency")) {
            hop_latency = timeFromUs(atof(argv[i + 1]));
            cout << "Hop latency set to " << timeAsUs(hop_latency) << endl;
            i++;
        } else if (!strcmp(argv[i], "-switch_latency")) {
            switch_latency = timeFromUs(atof(argv[i + 1]));
            cout << "Switch latency set to " << timeAsUs(switch_latency) << endl;
            i++;
        } else if (!strcmp(argv[i], "-ar_sticky_delta")) {
            ar_sticky_delta = atof(argv[i + 1]);
            cout << "Adaptive routing sticky delta " << ar_sticky_delta << "us" << endl;
            i++;
        } else if (!strcmp(argv[i], "-ar_granularity")) {
            if (!strcmp(argv[i + 1], "packet"))
                ar_sticky = FatTreeSwitch::PER_PACKET;
            else if (!strcmp(argv[i + 1], "flow"))
                ar_sticky = FatTreeSwitch::PER_FLOWLET;
            else {
                cout << "Expecting -ar_granularity packet|flow, found " << argv[i + 1] << endl;
                exit(1);
            }
            i++;
        } else if (!strcmp(argv[i], "-ar_method")) {
            if (!strcmp(argv[i + 1], "pause")) {
                cout << "Adaptive routing based on pause state " << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_pause;
            } else if (!strcmp(argv[i + 1], "queue")) {
                cout << "Adaptive routing based on queue size " << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_queuesize;
            } else if (!strcmp(argv[i + 1], "bandwidth")) {
                cout << "Adaptive routing based on bandwidth utilization " << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_bandwidth;
            } else if (!strcmp(argv[i + 1], "pqb")) {
                cout << "Adaptive routing based on pause, queuesize and bandwidth utilization "
                     << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_pqb;
            } else if (!strcmp(argv[i + 1], "pq")) {
                cout << "Adaptive routing based on pause, queuesize" << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_pq;
            } else if (!strcmp(argv[i + 1], "pb")) {
                cout << "Adaptive routing based on pause, bandwidth utilization" << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_pb;
            } else if (!strcmp(argv[i + 1], "qb")) {
                cout << "Adaptive routing based on queuesize, bandwidth utilization" << endl;
                FatTreeSwitch::fn = &FatTreeSwitch::compare_qb;
            } else {
                cout
                    << "Unknown AR method expecting one of pause, queue, bandwidth, pqb, pq, pb, qb"
                    << endl;
                exit(1);
            }
            i++;
        } else if (!strcmp(argv[i], "-strat")) {
            if (!strcmp(argv[i + 1], "ecmp_host")) {
                route_strategy = ECMP_FIB;
                FatTreeSwitch::set_strategy(FatTreeSwitch::ECMP);
            } else if (!strcmp(argv[i + 1], "rr_ecmp")) {
                // this is the host route strategy;
                route_strategy = ECMP_FIB_ECN;
                qt             = COMPOSITE_ECN_LB;
                // this is the switch route strategy.
                FatTreeSwitch::set_strategy(FatTreeSwitch::RR_ECMP);
            } else if (!strcmp(argv[i + 1], "ecmp_host_ecn")) {
                route_strategy = ECMP_FIB_ECN;
                FatTreeSwitch::set_strategy(FatTreeSwitch::ECMP);
                qt = COMPOSITE_ECN_LB;
            } else if (!strcmp(argv[i + 1], "reactive_ecn")) {
                // Jitu's suggestion for something really simple
                // One path at a time, but switch whenever we get a trim or ecn
                // this is the host route strategy;
                route_strategy = REACTIVE_ECN;
                FatTreeSwitch::set_strategy(FatTreeSwitch::ECMP);
                qt = COMPOSITE_ECN_LB;
            } else if (!strcmp(argv[i + 1], "ecmp_ar")) {
                route_strategy    = ECMP_FIB;
                path_entropy_size = 1;
                FatTreeSwitch::set_strategy(FatTreeSwitch::ADAPTIVE_ROUTING);
            } else if (!strcmp(argv[i + 1], "ecmp_host_ar")) {
                route_strategy = ECMP_FIB;
                FatTreeSwitch::set_strategy(FatTreeSwitch::ECMP_ADAPTIVE);
                // the stuff below obsolete
                // FatTreeSwitch::set_ar_fraction(atoi(argv[i+2]));
                // cout << "AR fraction: " << atoi(argv[i+2]) << endl;
                // i++;
            } else if (!strcmp(argv[i + 1], "ecmp_rr")) {
                // switch round robin
                route_strategy    = ECMP_FIB;
                path_entropy_size = 1;
                FatTreeSwitch::set_strategy(FatTreeSwitch::RR);
            }
            i++;
        } else {
            cout << "Unknown parameter " << argv[i] << endl;
            exit_error(argv[0]);
        }
        i++;
    }

    assert(trimsize >= 64 && trimsize <= (uint32_t)packet_size);

    srand(seed);
    srandom(seed);
    cout << "Parsed args\n";
    Packet::set_packet_size(packet_size);

    if (route_strategy == NOT_SET) {
        route_strategy = ECMP_FIB;
        FatTreeSwitch::set_strategy(FatTreeSwitch::ECMP);
    }

    EqdsPullPacer::_oversubscribed_cc = receiver_oversubscribed_cc;

    if (EqdsSrc::_sender_based_cc) {
        EqdsSink::_bytes_unacked_threshold = 4000;
    };

    if (ecn) {
        ecn_low  = memFromPkt(ecn_low);
        ecn_high = memFromPkt(ecn_high);
        FatTreeTopology::set_ecn_parameters(true, false, ecn_low, ecn_high);
    }

    /*
    EqdsSink::_oversubscribed_congestion_control = oversubscribed_congestion_control;
    */

    if (receiver_oversubscribed_cc)
        cout << "Using experimental receiver-based oversubscribed congestion control " << endl;

    FatTreeSwitch::_ar_sticky              = ar_sticky;
    FatTreeSwitch::_sticky_delta           = timeFromUs(ar_sticky_delta);
    FatTreeSwitch::_ecn_threshold_fraction = ecn_thresh;
    FatTreeSwitch::_trim_size              = trimsize;

    eventlist.setEndtime(timeFromUs((uint32_t)end_time));
    queuesize = memFromPkt(queuesize);

    // 2 priority queues; 3 hops for incast
    EqdsSrc::_min_rto = timeFromUs(150 + queuesize * 6.0 * 8 * 1000000 / linkspeed);

    cout << "Setting queuesize to " << queuesize << endl;
    cout << "Setting min RTO to " << timeAsUs(EqdsSrc::_min_rto) << endl;

    switch (route_strategy) {
        case ECMP_FIB_ECN:
        case REACTIVE_ECN:
            if (qt != COMPOSITE_ECN_LB) {
                fprintf(stderr, "Route Strategy is ECMP ECN.  Must use an ECN queue\n");
                exit(1);
            }
            if (ecn_thresh <= 0 || ecn_thresh >= 1) {
                fprintf(stderr,
                        "Route Strategy is ECMP ECN.  ecn_thresh must be between 0 and 1\n");
                exit(1);
            }
            // no break, fall through
        case ECMP_FIB:
            if (path_entropy_size > 10000) {
                fprintf(stderr, "Route Strategy is ECMP.  Must specify path count using -paths\n");
                exit(1);
            }
            break;
        case NOT_SET:
            fprintf(stderr,
                    "Route Strategy not set.  Use the -strat param.  \nValid values are perm, "
                    "rand, pull, rg and single\n");
            exit(1);
        default:
            break;
    }

    // prepare the loggers

    cout << "Logging to " << filename.str() << endl;
    // Logfile
    Logfile logfile(filename.str(), eventlist);

    cout << "Linkspeed set to " << linkspeed / 1000000000 << "Gbps" << endl;
    logfile.setStartTime(timeFromSec(0));

    EqdsSinkLoggerSampling* sink_logger = NULL;
    if (log_sink) {
        sink_logger = new EqdsSinkLoggerSampling(logtime, eventlist);
        logfile.addLogger(*sink_logger);
    }
    NicLoggerSampling* nic_logger = NULL;
    if (log_nic) {
        nic_logger = new NicLoggerSampling(logtime, eventlist);
        logfile.addLogger(*nic_logger);
    }
    TrafficLoggerSimple* traffic_logger = NULL;
    if (log_traffic) {
        traffic_logger = new TrafficLoggerSimple();
        logfile.addLogger(*traffic_logger);
    }
    FlowEventLoggerSimple* event_logger = NULL;
    if (log_flow_events) {
        event_logger = new FlowEventLoggerSimple();
        logfile.addLogger(*event_logger);
    }

    // EqdsSrc::setMinRTO(50000); //increase RTO to avoid spurious retransmits
    EqdsSrc::_path_entropy_size = path_entropy_size;

    EqdsSrc*  eqds_src;
    EqdsSink* eqds_snk;

    // Route* routeout, *routein;

    // scanner interval must be less than min RTO
    // EqdsRtxTimerScanner EqdsRtxScanner(timeFromUs((uint32_t)9), eventlist);

    QueueLoggerFactory* qlf = 0;
    if (log_tor_downqueue || log_tor_upqueue) {
        qlf = new QueueLoggerFactory(&logfile, QueueLoggerFactory::LOGGER_SAMPLING, eventlist);
        qlf->set_sample_period(timeFromUs(10.0));
    } else if (log_queue_usage) {
        qlf = new QueueLoggerFactory(&logfile, QueueLoggerFactory::LOGGER_EMPTY, eventlist);
        qlf->set_sample_period(timeFromUs(10.0));
    }

    ConnectionMatrix* conns = new ConnectionMatrix(no_of_nodes);

    if (tm_file) {
        cout << "Loading connection matrix from  " << tm_file << endl;

        if (!conns->load(tm_file)) {
            cout << "Failed to load connection matrix " << tm_file << endl;
            exit(-1);
        }
    } else {
        cout << "Loading connection matrix from  standard input" << endl;
        conns->load(cin);
    }

    if (conns->N != no_of_nodes && no_of_nodes != 0) {
        cout << "Connection matrix number of nodes is " << conns->N << " while I am using "
             << no_of_nodes << endl;
        exit(-1);
    }

    no_of_nodes = conns->N;

    vector<FatTreeTopology*> topo;
    topo.resize(planes);
    for (uint32_t p = 0; p < planes; p++) {
        if (topo_file) {
            topo[p] = FatTreeTopology::load(topo_file, qlf, eventlist, queuesize, qt, snd_type);
            if (topo[p]->no_of_nodes() != no_of_nodes) {
                cerr << "Mismatch between connection matrix (" << no_of_nodes
                     << " nodes) and topology (" << topo[p]->no_of_nodes() << " nodes)" << endl;
                exit(1);
            }
        } else {
            FatTreeTopology::set_tiers(tiers);
            topo[p] = new FatTreeTopology(no_of_nodes,
                                          linkspeed,
                                          queuesize,
                                          qlf,
                                          &eventlist,
                                          NULL,
                                          qt,
                                          hop_latency,
                                          switch_latency,
                                          snd_type);
        }

        if (log_switches) {
            topo[p]->add_switch_loggers(logfile, timeFromUs(20.0));
        }
    }

    // handle link failures specified in the connection matrix.
    for (size_t c = 0; c < conns->failures.size(); c++) {
        failure* crt = conns->failures.at(c);

        cout << "Adding link failure switch type" << crt->switch_type << " Switch ID "
             << crt->switch_id << " link ID " << crt->link_id << endl;
        // xxx we only support failures in plane 0 for now.
        topo[0]->add_failed_link(crt->switch_type, crt->switch_id, crt->link_id);
    }

    vector<EqdsPullPacer*> pacers;
    vector<EqdsNIC*>       nics;

    for (size_t ix = 0; ix < no_of_nodes; ix++) {
        pacers.push_back(new EqdsPullPacer(linkspeed, 0.99, EqdsSrc::_mtu, eventlist, ports));
        EqdsNIC* nic = new EqdsNIC(ix, eventlist, linkspeed, ports);
        nics.push_back(nic);
        if (log_nic) {
            nic_logger->monitorNic(nic);
        }
    }

    // used just to print out stats data at the end
    list<const Route*> routes;

    vector<connection*>* all_conns = conns->getAllConnections();
    vector<EqdsSrc*>     eqds_srcs;

    map<flowid_t, TriggerTarget*> flowmap;

    for (size_t c = 0; c < all_conns->size(); c++) {
        connection* crt  = all_conns->at(c);
        int         src  = crt->src;
        int         dest = crt->dst;
        // cout << "Connection " << crt->src << "->" <<crt->dst << " starting at " << crt->start <<
        // " size " << crt->size << endl;

        eqds_src = new EqdsSrc(traffic_logger, eventlist, *nics.at(src), ports);
        eqds_src->setCwnd(cwnd * Packet::data_packet_size());
        eqds_src->setMaxWnd(cwnd * Packet::data_packet_size());
        eqds_srcs.push_back(eqds_src);
        eqds_src->setDst(dest);

        if (log_flow_events) {
            eqds_src->logFlowEvents(*event_logger);
        }

        if (receiver_driven)
            eqds_snk = new EqdsSink(NULL, pacers[dest], *nics.at(dest), ports);
        else  // each connection has its own pacer, so receiver driven mode does not kick in!
            eqds_snk = new EqdsSink(
                NULL, linkspeed, 0.99, EqdsSrc::_mtu, eventlist, *nics.at(dest), ports);

        eqds_src->setName("Eqds_" + ntoa(src) + "_" + ntoa(dest));
        logfile.writeName(*eqds_src);
        eqds_snk->setSrc(src);

        eqds_snk->setName("Eqds_sink_" + ntoa(src) + "_" + ntoa(dest));
        logfile.writeName(*eqds_snk);

        if (crt->flowid) {
            eqds_src->setFlowId(crt->flowid);
            eqds_snk->setFlowId(crt->flowid);
            assert(flowmap.find(crt->flowid) == flowmap.end());  // don't have dups
            flowmap[crt->flowid] = eqds_src;
        }

        if (crt->size > 0) {
            eqds_src->setFlowsize(crt->size);
        }

        if (crt->trigger) {
            Trigger* trig = conns->getTrigger(crt->trigger, eventlist);
            trig->add_target(*eqds_src);
        }
        if (crt->send_done_trigger) {
            Trigger* trig = conns->getTrigger(crt->send_done_trigger, eventlist);
            eqds_src->setEndTrigger(*trig);
        }

        if (crt->recv_done_trigger) {
            Trigger* trig = conns->getTrigger(crt->recv_done_trigger, eventlist);
            eqds_snk->setEndTrigger(*trig);
        }

        // eqds_snk->set_priority(crt->priority);

        // EqdsRtxScanner.registerEqds(*EqdsSrc);
        for (uint32_t p = 0; p < planes; p++) {
            switch (route_strategy) {
                case ECMP_FIB:
                case ECMP_FIB_ECN:
                case REACTIVE_ECN: {
                    Route* srctotor = new Route();
                    srctotor->push_back(
                        topo[p]->queues_ns_nlp[src][topo[p]->HOST_POD_SWITCH(src)][0]);
                    srctotor->push_back(
                        topo[p]->pipes_ns_nlp[src][topo[p]->HOST_POD_SWITCH(src)][0]);
                    srctotor->push_back(topo[p]
                                            ->queues_ns_nlp[src][topo[p]->HOST_POD_SWITCH(src)][0]
                                            ->getRemoteEndpoint());

                    Route* dsttotor = new Route();
                    dsttotor->push_back(
                        topo[p]->queues_ns_nlp[dest][topo[p]->HOST_POD_SWITCH(dest)][0]);
                    dsttotor->push_back(
                        topo[p]->pipes_ns_nlp[dest][topo[p]->HOST_POD_SWITCH(dest)][0]);
                    dsttotor->push_back(topo[p]
                                            ->queues_ns_nlp[dest][topo[p]->HOST_POD_SWITCH(dest)][0]
                                            ->getRemoteEndpoint());

                    eqds_src->connectPort(p, *srctotor, *dsttotor, *eqds_snk, crt->start);
                    // eqds_src->setPaths(path_entropy_size);
                    // eqds_snk->setPaths(path_entropy_size);

                    // register src and snk to receive packets from their respective TORs.
                    assert(topo[p]->switches_lp[topo[p]->HOST_POD_SWITCH(src)]);
                    assert(topo[p]->switches_lp[topo[p]->HOST_POD_SWITCH(src)]);
                    topo[p]->switches_lp[topo[p]->HOST_POD_SWITCH(src)]->addHostPort(
                        src, eqds_snk->flowId(), eqds_src->getPort(p));
                    topo[p]->switches_lp[topo[p]->HOST_POD_SWITCH(dest)]->addHostPort(
                        dest, eqds_src->flowId(), eqds_snk->getPort(p));
                    break;
                }
                default:
                    abort();
            }
        }

        // set up the triggers
        // xxx

        if (log_sink) {
            sink_logger->monitorSink(eqds_snk);
        }
    }

    Logged::dump_idmap();
    // Record the setup
    int pktsize = Packet::data_packet_size();
    logfile.write("# pktsize=" + ntoa(pktsize) + " bytes");
    logfile.write("# hostnicrate = " + ntoa(linkspeed / 1000000) + " Mbps");
    // logfile.write("# corelinkrate = " + ntoa(HOST_NIC*CORE_TO_HOST) + " pkt/sec");
    // logfile.write("# buffer = " + ntoa((double) (queues_na_ni[0][1]->_maxsize) / ((double)
    // pktsize)) + " pkt");

    // GO!
    cout << "Starting simulation" << endl;
    while (eventlist.doNextEvent()) {
    }

    cout << "Done" << endl;
    int new_pkts = 0, rtx_pkts = 0, bounce_pkts = 0, rts_pkts = 0;
    for (size_t ix = 0; ix < eqds_srcs.size(); ix++) {
        new_pkts += eqds_srcs[ix]->_new_packets_sent;
        rtx_pkts += eqds_srcs[ix]->_rtx_packets_sent;
        rts_pkts += eqds_srcs[ix]->_rts_packets_sent;
        bounce_pkts += eqds_srcs[ix]->_bounces_received;
    }
    cout << "New: " << new_pkts << " Rtx: " << rtx_pkts << " RTS: " << rts_pkts
         << " Bounced: " << bounce_pkts << endl;
    /*
    list <const Route*>::iterator rt_i;
    int counts[10]; int hop;
    for (int i = 0; i < 10; i++)
        counts[i] = 0;
    cout << "route count: " << routes.size() << endl;
    for (rt_i = routes.begin(); rt_i != routes.end(); rt_i++) {
        const Route* r = (*rt_i);
        //print_route(*r);
#ifdef PRINTPATHS
        cout << "Path:" << endl;
#endif
        hop = 0;
        for (int i = 0; i < r->size(); i++) {
            PacketSink *ps = r->at(i);
            CompositeQueue *q = dynamic_cast<CompositeQueue*>(ps);
            if (q == 0) {
#ifdef PRINTPATHS
                cout << ps->nodename() << endl;
#endif
            } else {
#ifdef PRINTPATHS
                cout << q->nodename() << " " << q->num_packets() << "pkts "
                     << q->num_headers() << "hdrs " << q->num_acks() << "acks " << q->num_nacks() <<
"nacks " << q->num_stripped() << "stripped"
                     << endl;
#endif
                counts[hop] += q->num_stripped();
                hop++;
            }
        }
#ifdef PRINTPATHS
        cout << endl;
#endif
    }
    for (int i = 0; i < 10; i++)
        cout << "Hop " << i << " Count " << counts[i] << endl;
    */
}
