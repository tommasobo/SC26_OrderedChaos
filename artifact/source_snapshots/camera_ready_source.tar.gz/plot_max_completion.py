import argparse
import re
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from typing import Optional

PROGRESS_RE = re.compile(r'progress:\s*(\d+)\s*%\s*\(\s*\d+\s*\)\s*-\s*(\d+)')

def infer_algo(filename: str) -> str:
    """
    Infer algorithm (rss, reps, ecmp, rss1, rss2, etc.) from filename like:
      rss_nodrop.txt, reps_drop.txt, rss1_drop.txt
    """
    base = filename.split('.')[0]
    return base.split('_')[0]

def parse_file(path: Path):
    max_progress = None
    completion_time = None
    with path.open('r', errors='ignore') as f:
        for line in f:
            m = PROGRESS_RE.search(line)
            if m:
                pct = int(m.group(1))
                ctime = int(m.group(2))
                if (max_progress is None) or (pct > max_progress) or (pct == max_progress and ctime > completion_time):
                    max_progress = pct
                    completion_time = ctime
    return max_progress, completion_time

def collect_files(files):
    rows = []
    for p in sorted(files):
        if p.is_file():
            prog, ctime = parse_file(p)
            if prog is not None and ctime is not None:
                algo = infer_algo(p.name)
                status = "nodrop" if "_nodrop" in p.name else "drop" if "_drop" in p.name else "unknown"
                rows.append({
                    "file": p.name,
                    "algo": algo,
                    "status": status,
                    "max_progress_pct": prog,
                    "completion_time_ns": ctime,
                    "completion_time_ms": ctime / 1e6
                })
    return pd.DataFrame(rows)

# Added: filename -> x-axis label translation (dummy values; replace later)
def translate_label(name: str) -> str:
    mapping = {
        "60_no_rss.tmp": "RSS\nNo D.",
        "60_no_reps.tmp": "REPS\nNo D.",
        "60_no_ecmp.tmp": "ECMP\nNo D.",
        "60_drop_rss.tmp": "RSS\nYes D.",
        "60_drop_reps.tmp": "REPS\nYes D.",
        "60_drop_ecmp.tmp": "ECMP\nYes D.",
        "60_drop_rss_rtt.tmp": "RSS\nYes D.\nPer RTT",
        "60_drop_rss_one.tmp": "RSS\nYes D.\nPer Packet",
    }

    mapping = {
        "rss_nodrop.txt": "RSS\nNo Drop",\
        "reps_nodrop.txt": "REPS\nNo Drop",
        "ecmp_nodrop.txt": "ECMP\nNo Drop",
        "rss_drop.txt": "RSS\nYes Drop",
        "reps_drop.txt": "REPS\nYes Drop",
        "ecmp_drop.txt": "ECMP\nYes Drop",
        "rss1_drop.txt": "RSS\nYes Drop (RTT)",
        "rss2_drop.txt": "RSS\nYes Drop (Pkt)",

    }
    return mapping.get(name, name)

def plot(df: pd.DataFrame, output: Path, sort: bool, comm_only: bool = False,
         compute_fraction: float = 0.55, baseline_file: Optional[str] = None):
    if df.empty:
        print("No data parsed; exiting.")
        return
    compute_fraction = max(0.0, min(1.0, compute_fraction))

    if comm_only:
        baseline_rows = pd.DataFrame()
        if baseline_file:
            baseline_rows = df[df["file"] == baseline_file]
            if baseline_rows.empty:
                print(f"Warning: baseline file '{baseline_file}' not found in data; falling back to ECMP baseline.")
        if baseline_file and not baseline_rows.empty:
            baseline_time_per_pct = dict(zip(baseline_rows["max_progress_pct"], baseline_rows["completion_time_ms"]))
        else:
            baseline_time_per_pct = (
                df[df["algo"] == "ecmp"]
                .groupby("max_progress_pct")["completion_time_ms"]
                .min()
                .to_dict()
            )
        const_compute_per_pct = {pct: t * compute_fraction for pct, t in baseline_time_per_pct.items()}
        def communication_time(row):
            comp_const = const_compute_per_pct.get(row.max_progress_pct)
            if comp_const is None:
                return row.completion_time_ms * (1.0 - compute_fraction)
            return max(row.completion_time_ms - comp_const, 0.0)
        df["effective_time_ms"] = df.apply(communication_time, axis=1)
    else:
        df["effective_time_ms"] = df["completion_time_ms"]

    if sort:
        df = df.sort_values("effective_time_ms", ascending=False).reset_index(drop=True)
    else:
        df = df.reset_index(drop=True)

    # --- NEW: collapse duplicate filenames (previously auto-aggregated by seaborn) ---
    dupe_counts = df["file"].value_counts()
    dupe_names = dupe_counts[dupe_counts > 1].index.tolist()
    if dupe_names:
        print("Collapsing duplicate file entries (keeping fastest): " + ", ".join(dupe_names))
        # Keep the min effective_time_ms per file (fastest)
        df = (
            df.sort_values("effective_time_ms")
              .drop_duplicates(subset=["file"], keep="first")
              .reset_index(drop=True)
        )

    df["label"] = df["file"].apply(translate_label)

    plt.figure(figsize=(max(6, len(df)*0.4), 5))
    # Ensure one bar per row using a unique x position; then color per status
    status_palette = {"nodrop": "#53b280", "drop": "#c0696c", "unknown": "#888888"}
    df = df.reset_index(drop=True)
    df["pos"] = range(len(df))

    ax = sns.barplot(
        data=df,
        x="pos",
        y="effective_time_ms",
        ci=None,
        order=df["pos"].tolist(),
    )
    bars = ax.patches

    # Apply requested colors per status
    for i, bar in enumerate(bars):
        if i >= len(df):
            break
        bar.set_facecolor(status_palette.get(df.iloc[i]["status"], "#888888"))

    if comm_only:
        ax.set_ylabel("Communication Time (ms)")
        ax.set_title("Communication (non-overlapped) Time")
    else:
        ax.set_ylabel("Completion Time (ms)")
        ax.set_title("Max Completion Time")

    ax.set_xlabel("Algorithm Variant")
    ax.set_xticks(df["pos"])    
    ax.set_xticklabels(df["label"], rotation=75)

    # Annotations setup requires a chosen baseline; select it now
    available_files = set(df["file"])
    if baseline_file and baseline_file in available_files:
        baseline_df = df[df["file"] == baseline_file]
        baseline_source = "user-specified"
    else:
        if baseline_file and baseline_file not in available_files:
            print(f"Warning: requested baseline_file '{baseline_file}' not found; falling back.")
        if "ecmp_nodrop.txt" in available_files:
            baseline_file = "ecmp_nodrop.txt"
            baseline_df = df[df["file"] == baseline_file]
            baseline_source = "default-ecmp-nodrop"
        else:
            idx = df["effective_time_ms"].idxmin()
            baseline_df = df.loc[[idx]]
            baseline_file = baseline_df.iloc[0]["file"]
            baseline_source = "fallback-global-min"

    baseline_value = float(baseline_df.iloc[0]["effective_time_ms"])
    baseline_file_chosen = baseline_df.iloc[0]["file"]

    def uniform_speedup(row):
        if row.file == baseline_file_chosen:
            return 0.0
        if baseline_value == 0:
            return float('nan')
        return (baseline_value - row.effective_time_ms) / baseline_value * 100.0
    df["speedup_pct"] = df.apply(uniform_speedup, axis=1)

    # Annotations (aligned with bars because order preserved)
    for i, bar in enumerate(bars):
        if i >= len(df):
            break
        row = df.iloc[i]
        height = bar.get_height()
        if row.file == baseline_file_chosen:
            text = "Baseline"
        else:
            sp = row.speedup_pct
            if pd.isna(sp):
                continue
            if abs(sp) < 0.05:
                text = "same"
            else:
                sign = "+" if sp > 0 else ""
                text = f"{sign}{sp:.1f}%"
        ax.annotate(text,
                    (bar.get_x() + bar.get_width() / 2.0, height),
                    ha="center", va="bottom", fontsize=7)

    # Manual legend built from existing bar artists (no extra imports)
    handle_map = {}
    for i, bar in enumerate(bars):
        if i >= len(df):
            break
        status = df.iloc[i]["status"]
        if status not in handle_map:
            handle_map[status] = bar
    legend_order = [s for s in ["nodrop", "drop", "unknown"] if s in handle_map]
    if legend_order:
        legend_label_map = {"nodrop": "0% Corruption Drops", "drop": "0.0001 Corruption Drops", "unknown": "unknown"}
        ax.legend(handles=[handle_map[s] for s in legend_order],
                  labels=[legend_label_map.get(s, s) for s in legend_order],
                  loc="upper left", title=None)

    plt.tight_layout()
    plt.savefig(output)
    print(f"Saved plot to {output} (baseline: {baseline_file_chosen} [{baseline_source}], value={baseline_value:.3f} ms)")

def main():
    ap = argparse.ArgumentParser(
        description="Plot completion times combining baseline *_nodrop.txt and a chosen drop_<rate> subfolder."
    )
    ap.add_argument("directory", nargs='?', default="logs", help="Base directory produced by compare.py (default: logs)")
    ap.add_argument("--drop-rate", dest="drop_rate", required=True,
                    help="Drop rate subfolder to include (e.g. 0.01 for directory drop_0.01)")
    ap.add_argument("--output", default="max_completion_times.png", help="Output image filename")
    ap.add_argument("--comm-only", action="store_true", help="Show only communication time component")
    ap.add_argument("--compute-fraction", type=float, default=0.55,
                    help="Fraction of baseline runtime considered immutable compute (default 0.55)")
    ap.add_argument("--baseline-file",
                    dest="baseline_file",
                    help="Explicit baseline filename (default: inferred ECMP nodrop)")
    ap.add_argument("--no-sort", action="store_true", help="Keep original order instead of sorting by time desc")
    args = ap.parse_args()

    base_dir = Path(args.directory).resolve()
    if not base_dir.is_dir():
        print(f"Directory not found: {base_dir}")
        return

    drop_dir = base_dir / f"drop_{args.drop_rate}"
    if not drop_dir.is_dir():
        print(f"Drop directory not found: {drop_dir}")
        return

    # Collect baseline nodrop (top-level)
    baseline_files = list(base_dir.glob("*_nodrop.txt"))
    # Collect drop files (and optionally nodrop duplicates inside subfolder)
    drop_files = list(drop_dir.glob("*.txt"))

    df_baseline = collect_files(baseline_files)
    df_drop = collect_files(drop_files)

    df = pd.concat([df_baseline, df_drop], ignore_index=True)
    if df.empty:
        print("No progress lines found in selected files.")
        return

    plot(df,
         Path(args.output),
         sort=not args.no_sort,
         comm_only=args.comm_only,
         compute_fraction=args.compute_fraction,
         baseline_file=args.baseline_file)

if __name__ == "__main__":
    main()
