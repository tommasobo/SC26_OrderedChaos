import re
import argparse
import matplotlib.pyplot as plt
import math

def parse_loss(logfile):
    total = 0
    lost = 0
    pattern = re.compile(r"lost packets (\-?\d+)")
    with open(logfile) as f:
        for line in f:
            m = pattern.search(line)
            if m:
                total += 1
                if int(m.group(1)) > 0:
                    lost += 1
    return total, lost

def main():
    parser = argparse.ArgumentParser(
        description="Count flows with packet loss"
    )
    parser.add_argument("--logfile", help="Path to log file")
    args = parser.parse_args()

    total, lost = parse_loss(args.logfile)
    print(f"Total flows: {total}")
    print(f"Flows with loss: {lost} ({lost/total:.1%})")

    # simple pie chart
    labels = ["No Loss", "With Loss"]
    sizes = [total - lost, lost]
    wedges, texts, autotexts = plt.pie(sizes, labels=labels, autopct="%1.1f%%")
    plt.title(f"Flows with vs. without packet loss (Total: {total*10})")

    # annotate counts on slices
   #

    # save as PNG
    plt.savefig("llama3.png", dpi=200, bbox_inches="tight")
    plt.show()

if __name__ == "__main__":
    main()
