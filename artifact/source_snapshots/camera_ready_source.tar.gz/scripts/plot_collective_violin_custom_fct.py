import subprocess
import re
import tempfile
import os
import matplotlib.pyplot as plt
import argparse
import concurrent.futures      # added for parallel runs
import csv

plt.rcParams.update({'font.size': 14})

# parse rto_ratio and iterations from CLI
parser = argparse.ArgumentParser(description="Run htsim and plot runtimes")
parser.add_argument('--iterations', type=int, default=1,
                    help='Number of simulator iterations')
parser.add_argument('--rto_ratio', type=int, default=1,
                    help='RTO ratio for simulator')
parser.add_argument('--switch_random_drop_prob', type=float, default=0.0,
                    help='Switch random drop probability')
parser.add_argument('--workers', type=int, default=os.cpu_count(),
                    help='Number of parallel workers')
parser.add_argument('--log_dir', type=str, default="testing",
                    help='Directory to save simulator stdout logs')
# NEW: output filename for the figure
parser.add_argument('--output', type=str, default="dlrm_runtime_per_iteration_bar.png",
                    help='Output image filename')
args = parser.parse_args()
# Force one iteration
iterations = 1
rto_ratio = str(args.rto_ratio)
switch_random_drop_prob = str(args.switch_random_drop_prob)
workers = args.workers
log_dir = args.log_dir
if log_dir:
    os.makedirs(log_dir, exist_ok=True)

# define the algorithms and how to invoke them
algorithm_configs = [
    {"name": "RSS+PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+1PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+2PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+3PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+4PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
]
algorithms = [cfg["name"] for cfg in algorithm_configs]

# Create dict to store per-flow completion times (us) for each algorithm
runtimes = {name: [] for name in algorithms}
# NEW: track flow ids aligned with runtimes
flow_ids_by_alg = {name: [] for name in algorithms}
# NEW: store lost packet counts per algorithm
lost_packets = {name: [] for name in algorithms}

# common simulator args (no -end here)
htsim = "/home/a-tobonato/M/msft-htsim/build/htsim_uec"
data_cfg = "/home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json"
goal = "/home/a-tobonato/M/msft-htsim/scripts/connection_matrices_old/allreduce_8.cm"
topo = "/home/a-tobonato/M/msft-htsim/scripts/topologies/topo=fat_tree:over_sub=1:nodes=128:link_speed_gbps=400.topo"
common_args = [
    htsim, "-data_collection_config", data_cfg, # -end removed
    "-tm", goal, "-topo", topo, "-q", "75", "-cwnd", "151", "-mtu", "4160",
    "-sack_threshold", "0", "-ecn", "38", "113",
    "-switch_random_drop_prob", switch_random_drop_prob,
    "-linkspeed", "400000",
    "-nodes", "128",
    "-iterations", str(1), "-rto_ratio", rto_ratio, "-lgs_percent", str(18)
]

def rename_xlabels(labels):
    # Dummy mapping; replace values as needed
    mapping = {
        "RSS+PFLD": "PFLD 16 Probe \n No Trim",
        "RSS+1PFLD": "PFLD 1 Probe \n No Trim",
        "RSS+2PFLD": "PFLD 2 Probe \n No Trim",
        "RSS+3PFLD": "PFLD 8 Probe \n No Trim",
        "RSS+4PFLD": "PFLD End Msg \n No Trim",
    }
    return [mapping.get(lbl, lbl) for lbl in labels]

def _to_us(val, unit):
    if unit is None:
        return float(val)
    u = unit.lower()
    if u == 'us': return float(val)
    if u == 'ps': return float(val) / 1e6
    if u == 'ns': return float(val) / 1e3
    if u == 'ms': return float(val) * 1e3
    if u == 's':  return float(val) * 1e6
    return float(val)

def _parse_flow_times_from_text(text):
    times = []
    # Common patterns seen in simulators/logs; adjust as needed
    regexes = [
        r"Flow\s+\d+.*?(?:finished|completion).*?(\d+(?:\.\d+)?)\s*(ps|ns|us|ms|s)?",
        r"\bFCT[:\s]+(\d+(?:\.\d+)?)\s*(ps|ns|us|ms|s)\b",
        r"flow[_\s]?completion[_\s]?time[:\s]+(\d+(?:\.\d+)?)\s*(ps|ns|us|ms|s)?",
    ]
    for rx in regexes:
        for m in re.finditer(rx, text, flags=re.IGNORECASE):
            times.append(_to_us(m.group(1), m.group(2)))
    # NEW: capture "finished at <float>" (assume microseconds)
    for m in re.finditer(r"\bfinished at\s+(\d+(?:\.\d+)?)\b", text, flags=re.IGNORECASE):
        times.append(_to_us(m.group(1), None))
    return times

# NEW: parse (flowId, finished_at_us) from full text (stdout/log)
def _parse_flow_pairs_from_text(text):
    pairs = []
    # Matches lines like:
    # Flow Uec_6_7 flowId 85 uecSrc 84 finished at 29.0675 total packets ...
    pattern = re.compile(r"Flow\s+[^\n]*?\bflowId\s+(\d+)[^\n]*?\bfinished at\s+(\d+(?:\.\d+)?)", re.IGNORECASE)
    for fid, t in pattern.findall(text):
        try:
            pairs.append((int(fid), float(t)))
        except Exception:
            pass
    return pairs

# NEW: primary parser for -o output file -> list[(flowId, fct_us)]
def _parse_finished_at_from_file(path):
    try:
        with open(path, 'r') as f:
            txt = f.read()
        return _parse_flow_pairs_from_text(txt)
    except Exception:
        return []

def _parse_flow_times_from_dir(data_dir):
    times = []
    if not os.path.isdir(data_dir):
        return times
    # Prefer a canonical flows.csv if present; else any csv with 'flow' in name
    candidates = []
    preferred = os.path.join(data_dir, "flows.csv")
    if os.path.exists(preferred):
        candidates = [preferred]
    else:
        try:
            for fn in os.listdir(data_dir):
                if fn.endswith(".csv") and "flow" in fn.lower():
                    candidates.append(os.path.join(data_dir, fn))
        except Exception:
            pass
    # Parse CSVs, look for an FCT-like column in microseconds
    for path in candidates:
        try:
            with open(path, newline='') as f:
                reader = csv.reader(f)
                header = next(reader, [])
                if not header:
                    continue
                # find a likely FCT column
                idx = None
                for i, h in enumerate(header):
                    hl = h.lower()
                    if ("fct" in hl or "completion" in hl or "finish" in hl) and ("time" in hl or "us" in hl):
                        idx = i
                        break
                if idx is None:
                    continue
                for row in reader:
                    if idx < len(row) and row[idx].strip():
                        try:
                            times.append(float(row[idx].strip()))
                        except ValueError:
                            pass
        except Exception:
            # ignore parse errors; try next candidate
            pass
    return times

# helper to run one (cfg, seed) and return (name, [flow_completion_times_us], [flow_ids])
def run_simulation(cfg, seed):
    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = os.path.join(tmpdir, "data")
        os.makedirs(data_dir, exist_ok=True)
        log_file = os.path.join(tmpdir, f"log_seed_{seed}.dat")
        cmd = common_args + ["-seed", str(seed), "-end", "100000", "-load_balancing_algo", cfg["algo"]]
        if cfg["disable_trim"]:
            cmd += ["-disable_trim"]
        if cfg["rss_params"]:
            cmd += ["-rss_parameters"] + cfg["rss_params"]
        # Avoid duplicating PFLD flags across variants
        if cfg["name"] == "RSS+PFLD":
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "16",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+1PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "1",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+2PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "2",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+3PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "8",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+4PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "0",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        cmd += ["-data_collection_dir", data_dir, "-o", log_file]

        # debug: show the exact command to be executed
        print("Executing command:", " ".join(cmd))
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if log_dir:
            outfn = os.path.join(log_dir, f"{cfg['name']}_seed_{seed}.log")
            with open(outfn, 'w') as lf:
                lf.write(res.stdout)

        # Count lost packets from output file
        lost = _count_lost_packets_from_file(log_file)

        # Primary: parse ALL (flowId, finished_at_us) from the -o output file
        pairs = _parse_finished_at_from_file(log_file)

        # Fallbacks with pairs from stdout/log
        if not pairs:
            pairs = _parse_flow_pairs_from_text(res.stdout)
        if not pairs and os.path.exists(log_file):
            try:
                with open(log_file, 'r') as lf:
                    pairs = _parse_flow_pairs_from_text(lf.read())
            except Exception:
                pass

        if pairs:
            times_us = [t for (_, t) in pairs]
            flow_ids = [fid for (fid, _) in pairs]
            return cfg["name"], times_us, flow_ids, lost

        # Fallbacks without flow ids (align flow_ids with None)
        times_us = _parse_flow_times_from_dir(data_dir)
        flow_ids = [None] * len(times_us)
        if not times_us:
            times_us = _parse_flow_times_from_text(res.stdout)
            flow_ids = [None] * len(times_us)
        if not times_us and os.path.exists(log_file):
            try:
                with open(log_file, 'r') as lf:
                    times_us = _parse_flow_times_from_text(lf.read())
                    flow_ids = [None] * len(times_us)
            except Exception:
                pass

        # Final fallback to single max if nothing else found
        if not times_us:
            times = re.findall(r"Maximum finishing time at host \d+:\s+(\d+)", res.stdout)
            if not times:
                times = re.findall(r"progress:\s*\d+\s*%\s*\(\d+\)\s*-\s*(\d+)", res.stdout)
                if not times:
                    ps_times = re.findall(r"\bcurrent time\s+(\d+)", res.stdout)
                    if ps_times:
                        return cfg["name"], [max(float(t) for t in ps_times) / 1e6], [None], lost
                    raise RuntimeError(f"could not parse per-flow runtimes for {cfg['name']} (seed {seed})")
            return cfg["name"], [max(float(t) for t in times)], [None], lost

        return cfg["name"], times_us, flow_ids, lost

# replace nested loops with a pool of workers
tasks = [(cfg, 1) for cfg in algorithm_configs]
with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
    for name, times_us, fids, lost in executor.map(lambda t: run_simulation(t[0], t[1]), tasks):
        runtimes[name].extend(times_us)
        flow_ids_by_alg[name].extend(fids)
        lost_packets[name].append(lost)

# Colors palette and per-bar color mapping by trimming status
colors = ["#262636", "#7e2c40", "#a42f44", "#d85034",
          "#ee8143", "#228a8d", "#145a5c", "#45448b",
          "#7c7ae6", "#3885cf"]
bar_colors = [colors[1] if not cfg["disable_trim"] else colors[0] for cfg in algorithm_configs]

# Create violin plot of per-flow completion times (one violin per algorithm)
filtered = [(name, runtimes[name]) for name in algorithms if len(runtimes[name]) > 0]
if not filtered:
    raise RuntimeError("No flow completion times collected to plot.")

plot_names, plot_data = zip(*filtered)

# Map colors for filtered algorithms (by trimming status)
name_to_cfg = {cfg["name"]: cfg for cfg in algorithm_configs}
plot_colors = [colors[1] if not name_to_cfg[n]["disable_trim"] else colors[0] for n in plot_names]

plt.figure(figsize=(8, 6))
parts = plt.violinplot(plot_data, showmeans=False, showmedians=True, showextrema=False)

# Style violins
for i, body in enumerate(parts['bodies']):
    body.set_facecolor(plot_colors[i])
    body.set_edgecolor("black")
    body.set_alpha(0.7)
if 'cmedians' in parts:
    parts['cmedians'].set_edgecolor('black')
    parts['cmedians'].set_linewidth(1.5)

# X-axis positions are 1..N for matplotlib.violinplot
positions = range(1, len(plot_names) + 1)
plt.xticks(positions, rename_xlabels(list(plot_names)), fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Labels and title
plt.xlabel("Algorithm", fontsize=16)
plt.ylabel("Flow completion time (us)", fontsize=16)
plt.title("Ring AllReduce, per-flow completion times", fontsize=18)

# NEW: print the flowId for the max point in each violin
for name in plot_names:
    times = runtimes[name]
    fids = flow_ids_by_alg.get(name, [])
    if not times:
        continue
    idx = max(range(len(times)), key=lambda i: times[i])
    fid = fids[idx] if idx < len(fids) and fids[idx] is not None else "N/A"
    print(f"{name}: max flowId={fid}, fct_us={times[idx]}")

plt.tight_layout()
plt.savefig(args.output, dpi=300)
#plt.show()

# NEW: Lost packets violin plot
lost_filtered = [(name, lost_packets[name]) for name in algorithms if len(lost_packets[name]) > 0]
if lost_filtered:
    lost_names, lost_data = zip(*lost_filtered)
    plt.figure(figsize=(8, 6))
    parts = plt.violinplot(lost_data, showmeans=False, showmedians=True, showextrema=False)
    for i, body in enumerate(parts['bodies']):
        body.set_facecolor(plot_colors[i])
        body.set_edgecolor("black")
        body.set_alpha(0.7)
    if 'cmedians' in parts:
        parts['cmedians'].set_edgecolor('black')
        parts['cmedians'].set_linewidth(1.5)
    positions = range(1, len(lost_names) + 1)
    plt.xticks(positions, rename_xlabels(list(lost_names)), fontsize=10)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.xlabel("Algorithm", fontsize=16)
    plt.ylabel("Lost packets (count)", fontsize=16)
    plt.title("Ring AllReduce, lost packets per run", fontsize=18)
    plt.tight_layout()
    plt.savefig("lost_packets_violin.png", dpi=300)
    #plt.show()