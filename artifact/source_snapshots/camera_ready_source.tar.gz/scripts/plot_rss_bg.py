import os
import re
import argparse
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch

def parse_all_fcts(file_path):
    """Return (main_vals, bg_vals) per-flow completion times by is_bg flag."""
    pattern_fct = re.compile(r'finished at ([0-9.]+)')
    pattern_bg = re.compile(r'is_bg\s+([01])')
    main_vals, bg_vals = [], []
    # ignore invalid UTF-8 bytes when reading
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            mf = pattern_fct.search(line)
            if not mf:
                continue
            fct = float(mf.group(1))
            mbg = pattern_bg.search(line)
            is_bg = int(mbg.group(1)) if mbg else 0
            (bg_vals if is_bg == 1 else main_vals).append(fct)
    return main_vals, bg_vals

# add a rename map for visualization
RENAME_MAP = {
    "pfld2_no_trim": "PFLD (Probe every 16) -\nNo Trim",
    "pfld1_no_trim": "PFLD16 (Probe every 1) -\nNo Trim",
    "pfld0_no_trim": "PFLD16 (Probe every RTT) -\nNo Trim",
    "pfld3_no_trim": "PFLD16 (Probe only msg end) -\nNo Trim",
    "ecmp_no_trim": "ECMP - No Trim",
    "ecmp2_no_trim": "ECMP - No Trim - NACK PSN gap",
    "ecmp_trim": "ECMP",
    "flowbender_no_trim": "FlowBender - No Trim",
    "flowbender2_no_trim": "FlowBender - No Trim - NACK PSN gap",
    "flowbender_trim": "FlowBender",    
    "reps_no_trim": "REPS - No Trim",
    "reps_trim": "REPS",    
    "rps_no_trim": "RPS - No Trim",
    "rps_trim": "RPS",    
    "pfld1_trim": "RSS",  
    "rss_trim": "RSS",   
    "rss_no_trim": "RSS - No Trim",
    "rss2_no_trim": "RSS - No Trim - NACK PSN gap",
    "rss_1_trim": "RSS - 1 Subflow",   
    "rss_2_trim": "RSS - 2 Subflows",
    "rss_4_trim": "RSS - 4 Subflows",
    "rss_8_trim": "RSS - 8 Subflows",
    "rss_16_trim": "RSS - 16 Subflows",
    "rss_32_trim": "RSS - 32 Subflows",
}

def main():
    p = argparse.ArgumentParser(
        description="Plot per-flow completion times per LB+trim setting (violin)"
    )
    p.add_argument("--results_dir",
                   help="Base directory containing one sub-folder per run")
    p.add_argument("--output_dir",
                   help="Output directory containing one sub-folder per run")
    p.add_argument("-o", "--output",
                   default="max_fct_violin.png",
                   help="Filename for the saved violin plot")
    p.add_argument("--show", action="store_true",
                   help="Show the plot interactively after saving")
    p.add_argument("--show_ideal_tornado", default=0, type=int,
                   help="Show ideal tornado (single path) as baseline")
    p.add_argument("--order_rss", action="store_true",
                   help="Order x-axis as: RSS - 1, 2, 4, 8, 16, 32 Subflows when present")
    args = p.parse_args()

    # For main traffic
    labels_main = []
    all_values_main = []
    all_colors_main = []

    # For background traffic
    labels_bg = []
    all_values_bg = []
    all_colors_bg = []

    # our palette
    colors = ["#262636", "#7e2c40", "#a42f44", "#d85034", 
              "#ee8143", "#228a8d", "#145a5c", "#45448b", 
              "#7c7ae6", "#3885cf"]
    all_colors = []

    # each subfolder corresponds to one run
    for sub in sorted(os.listdir(args.results_dir)):
        # drop the entire “pfld2_trim” run
        if sub == "pfld2_trim" or sub == "pfld0_trim" or sub == "pfld3_trim":
            continue
        # apply rename if needed
        label = RENAME_MAP.get(sub, sub)
        subdir = os.path.join(args.results_dir, sub)
        if not os.path.isdir(subdir):
            continue

        # pick color: first color if “no_trim” in sub else second
        color = colors[0] if "no_trim" in sub else colors[6]

        # gather the single run's log files and extract all per-flow FCTs
        run_files = [
            fn for fn in os.listdir(subdir)
            if os.path.isfile(os.path.join(subdir, fn))
            and (
                (fn.startswith("log_seed_") and (fn.endswith(".out") or fn.endswith(".log")))
                or fn.endswith(".out") or fn.endswith(".log")
            )
        ]
        if not run_files:
            print(f"⚠️  no *.out or *.log in {subdir}, skipping")
            continue

        flow_main, flow_bg = [], []
        for fn in run_files:
            fm, fb = parse_all_fcts(os.path.join(subdir, fn))
            flow_main.extend(fm)
            flow_bg.extend(fb)

        if not flow_main and not flow_bg:
            print(f"⚠️  no 'finished at' entries found in {subdir}, skipping")
            continue

        label = RENAME_MAP.get(sub, sub)
        if flow_main:
            labels_main.append(label)
            all_values_main.append(flow_main)
            all_colors_main.append(color)
        if flow_bg:
            labels_bg.append(label)
            all_values_bg.append(flow_bg)
            all_colors_bg.append(color)

    # helper to sort/plot one class, preserving original look-and-feel
    def plot_violin(labels, all_values, all_colors, title_suffix, out_path):
        if not labels:
            print(f"⚠️  no data for {title_suffix}, skipping plot")
            return

        # rename labels for display
        labels = [RENAME_MAP.get(lbl, lbl) for lbl in labels]

        # sort everything (preserve original logic)
        items = list(zip(labels, all_values, all_colors))
        if args.order_rss:
            desired_order = [RENAME_MAP.get(k, k) for k in [
                "rss_1_trim", "rss_2_trim", "rss_4_trim",
                "rss_8_trim", "rss_16_trim", "rss_32_trim"
            ]]
            def sort_key(x):
                lbl = x[0]
                return (0, desired_order.index(lbl)) if lbl in desired_order else (1, lbl)
            items.sort(key=sort_key)
        else:
            items.sort(key=lambda x: x[0])

        labels, all_values, all_colors = zip(*items)
        labels = list(labels)
        all_values = list(all_values)
        all_colors = list(all_colors)

        # violin plot (same styling)
        plt.figure(figsize=(10,6))
        parts = plt.violinplot(
            all_values,
            showmeans=False,
            showmedians=True,
            showextrema=True
        )

        # color each violin body
        for body, col in zip(parts['bodies'], all_colors):
            body.set_facecolor(col)
            body.set_edgecolor('black')
            body.set_alpha(0.7)

        # color the interior lines
        for coll_name in ('cmins', 'cmaxes', 'cmedians', 'cbars'):
            lc = parts.get(coll_name)
            if lc is not None:
                lc.set_color(all_colors)
                lc.set_linewidth(1.0)
                lc.set_zorder(5)

        plt.xticks(range(1, len(labels)+1), labels, rotation=45, ha='right')
        plt.xlabel("Algorithm")
        plt.ylabel("Flow Completion Time")
        plt.title(f"FCT per LoadBalancing Algo & Trimming Mode ({title_suffix})")

        # horizontal grid
        ax = plt.gca()
        ax.set_axisbelow(True)
        ax.yaxis.grid(True, linestyle='--', linewidth=0.7, alpha=0.5)

        # 99th percentile overlay
        p99 = [np.percentile(vals, 99) for vals in all_values]
        xs  = range(1, len(labels) + 1)
        h99 = plt.scatter(xs, p99,
                          color='black',
                          marker='x',
                          label='99th percentile',
                          zorder=10)

        # legend (keep only p99 as before)
        plt.legend(handles=[h99], loc='upper right')

        # annotate min | mean | max
        global_min = min(min(v) for v in all_values)
        global_max = max(max(v) for v in all_values)
        y_offset = (global_max - global_min) * 0.03
        for idx, vals in enumerate(all_values):
            mi, me, ma = min(vals), np.mean(vals), max(vals)
            txt = f"{mi:.0f} | {me:.0f} | {ma:.0f}"
            plt.text(idx + 1, ma + y_offset, txt,
                     ha='center', va='bottom', fontsize=7.3)

        # optional ideal tornado line
        if (args.show_ideal_tornado > 0):
            perfect_time = (args.show_ideal_tornado * 8 * 1.04) / 400000 + 13
            plt.axhline(y=perfect_time, color='black', linestyle='--', label='Ideal Runtime\n(perfect fairness & no failures)')
            ax = plt.gca()
            xmin, xmax = ax.get_xlim()
            ax.text(
                xmax, perfect_time - y_offset * 0.6,
                f'Ideal completion time: {perfect_time:.0f} µs',
                ha='right', va='top', fontsize=9, color='black',
                bbox=dict(facecolor='white', alpha=0.6, edgecolor='none', pad=1.5),
                zorder=11
            )
            plt.legend(loc='upper right')

        # padding on top
        bottom, top = plt.ylim()
        plt.ylim(bottom, global_max + y_offset * 5)

        plt.tight_layout()
        os.makedirs(args.output_dir, exist_ok=True)
        plt.savefig(out_path)
        if args.show:
            plt.show()
        plt.close()

    # derive output filenames
    base, ext = os.path.splitext(args.output)
    out_main = os.path.join(args.output_dir, f"{base}_main{ext}")
    out_bg   = os.path.join(args.output_dir, f"{base}_bg{ext}")

    # generate both plots
    plot_violin(labels_main, all_values_main, all_colors_main, "Main traffic", out_main)
    plot_violin(labels_bg,   all_values_bg,   all_colors_bg,   "Background traffic", out_bg)

if __name__ == "__main__":
    main()