#!/usr/bin/env python3


import re
import json
import argparse
from typing import List, Tuple, Pattern, Iterable

Entry = Tuple[int, int, str, str]  # (size, line_no, line_text, kind)

BUILTIN_PATTERNS = {
    "send": [
        r"\bsend\s+(\d+)(?:b|bytes?)\b",
        r"\bsend[^0-9\n]{0,12}size[=:]\s*(\d+)\b",
    ],
    "recv": [
        r"\brecv\s+(\d+)(?:b|bytes?)\b",
        r"\brecv[^0-9\n]{0,12}size[=:]\s*(\d+)\b",
    ],
}

def parse_args():
    p = argparse.ArgumentParser(description="Extract largest send/recv messages from a log.")
    p.add_argument("file", help="Input text or JSON-lines file.")
    p.add_argument("--top", type=int, default=5, help="How many largest entries to show (default 5).")
    p.add_argument("--kinds", default="send", help="Comma list of kinds to scan: send,recv (default: send). Use 'send,recv' for both.")
    p.add_argument("--extra-pattern", action="append",
                   help="Additional regex with one capturing group for size. Can repeat.")
    p.add_argument("--json-key", default=None,
                   help="Treat each line as JSON and extract numeric field as size (disables text patterns).")
    p.add_argument("--min-size", type=int, default=0, help="Ignore sizes below this.")
    p.add_argument("--show-lines", action="store_true", help="Show full line content.")
    return p.parse_args()

def compile_many(patterns: List[str]) -> List[Pattern]:
    compiled = []
    for expr in patterns:
        try:
            compiled.append(re.compile(expr, re.IGNORECASE))
        except re.error as e:
            raise SystemExit(f"Invalid regex '{expr}': {e}")
    return compiled

def scan_regex(lines: List[str], pats: List[Pattern], kind: str, min_size: int) -> Iterable[Entry]:
    for idx, line in enumerate(lines, 1):
        for pat in pats:
            for m in pat.finditer(line):
                try:
                    size = int(m.group(1))
                except (ValueError, IndexError):
                    continue
                if size >= min_size:
                    yield (size, idx, line.rstrip("\n"), kind)

def scan_json(lines: List[str], key: str, min_size: int) -> Iterable[Entry]:
    for idx, line in enumerate(lines, 1):
        s = line.strip()
        if not s or not s.startswith("{"):
            continue
        try:
            obj = json.loads(s)
        except json.JSONDecodeError:
            continue
        val = obj.get(key)
        if isinstance(val, (int, float)):
            iv = int(val)
            if iv >= min_size:
                # Kind: use key name for clarity
                yield (iv, idx, line.rstrip("\n"), f"json:{key}")

def format_entry(e: Entry, show_line: bool) -> str:
    size, ln, text, kind = e
    if show_line:
        return f"{size}\t(line {ln})\t[{kind}]\t{text}"
    return f"{size}\t(line {ln})\t[{kind}]"

def main():
    args = parse_args()
    try:
        with open(args.file, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError as e:
        raise SystemExit(f"Cannot read file: {e}")

    entries: List[Entry] = []

    if args.json_key:
        # JSON mode only
        entries.extend(scan_json(lines, args.json_key, args.min_size))
    else:
        requested = {k.strip().lower() for k in args.kinds.split(",") if k.strip()}
        invalid = requested - {"send", "recv"}
        if invalid:
            raise SystemExit(f"Invalid kinds: {', '.join(sorted(invalid))}. Use send, recv.")
        for kind in sorted(requested):
            pats = BUILTIN_PATTERNS[kind][:]
            if args.extra_pattern:
                # Extra patterns apply to both kinds; label stays 'send'/'recv'
                pats.extend(args.extra_pattern)
            compiled = compile_many(pats)
            entries.extend(scan_regex(lines, compiled, kind, args.min_size))

    if not entries:
        if args.json_key:
            print(f"No matches found for JSON key '{args.json_key}'.")
        else:
            print("No matches found. Try:")
            print("  --kinds send,recv")
            print("  --extra-pattern 'send\\s+(\\d+)b'")
            print("  --json-key size")
        return

    entries.sort(key=lambda x: (-x[0], x[1]))
    top = entries[:args.top]

    print(f"Top {len(top)} message entries (size, line, kind):")
    for e in top:
        print(format_entry(e, args.show_lines))

    sizes = [e[0] for e in entries]
    total = len(entries)
    mean = sum(sizes) / total
    print(f"\nTotal: {total}  Max: {sizes[0]}  Mean: {mean:.2f}")

if __name__ == "__main__":
    main()
