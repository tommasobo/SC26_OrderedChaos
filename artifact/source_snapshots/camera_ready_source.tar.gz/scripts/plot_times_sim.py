import subprocess
import re
import tempfile
import os
import matplotlib.pyplot as plt
import argparse
import concurrent.futures      # added for parallel runs

plt.rcParams.update({'font.size': 14})

# parse rto_ratio and iterations from CLI
parser = argparse.ArgumentParser(description="Run htsim and plot runtimes")
parser.add_argument('--iterations', type=int, default=1,
                    help='Number of simulator iterations')
parser.add_argument('--rto_ratio', type=int, default=1,
                    help='RTO ratio for simulator')
parser.add_argument('--switch_random_drop_prob', type=float, default=0.0,
                    help='Switch random drop probability')
parser.add_argument('--workers', type=int, default=os.cpu_count(),
                    help='Number of parallel workers')
parser.add_argument('--log_dir', type=str, default="testing",
                    help='Directory to save simulator stdout logs')
# NEW: output filename for the figure
parser.add_argument('--output', type=str, default="dlrm_runtime_per_iteration_bar.png",
                    help='Output image filename')
args = parser.parse_args()
iterations = args.iterations
rto_ratio = str(args.rto_ratio)
switch_random_drop_prob = str(args.switch_random_drop_prob)
workers = args.workers
log_dir = args.log_dir
if log_dir:
    os.makedirs(log_dir, exist_ok=True)

# define the algorithms and how to invoke them
algorithm_configs = [
    {"name": "ECMP without trimming", "algo": "ecmp", "disable_trim": True, "rss_params": None},
    {"name": "REPS with trimming", "algo": "reps", "disable_trim": False, "rss_params": None},
    {"name": "RSS+PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "10", "0", "0", "25"]},
    {"name": "RSS+2PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "10", "0", "0", "25"]},
    {"name": "RSS without PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "10", "0", "0", "25"]},
    {"name": "RSS without PFLD+BitMap", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "10", "0", "0", "25"]},
    {"name": "RSS without PFLD - Yes Trimming", "algo": "rss", "disable_trim": False, "rss_params": ["mean_rtt", "16", "10", "0", "0", "25"]},
]
algorithms = [cfg["name"] for cfg in algorithm_configs]

# Create dict to store runtimes for each algorithm
runtimes = {name: [] for name in algorithms}

# common simulator args (no -end here)
htsim = "/home/a-tobonato/M/msft-htsim/build/htsim_uec"
data_cfg = "/home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json"
goal = "/home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin"
topo = "/home/a-tobonato/M/msft-htsim/scripts/topologies/topo=fat_tree:over_sub=2:nodes=128:link_speed_gbps=400.topo"
common_args = [
    htsim, "-data_collection_config", data_cfg, # -end removed
    "-goal", goal, "-topo", topo, "-q", "75", "-cwnd", "151", "-mtu", "4160",
    "-sack_threshold", "0", "-ecn", "38", "113",
    "-switch_random_drop_prob", switch_random_drop_prob,
    "-linkspeed", "100000", "-sender_cc_only", "-sender_cc_algo", "dctcp",
    "-nodes", "128",
    "-iterations", str(1), "-rto_ratio", rto_ratio, "-lgs_percent", str(2)
]


def rename_xlabels(labels):
    # Dummy mapping; replace values as needed
    mapping = {
        "REPS with trimming": "REPS \n Yes Trim",
        "RSS+PFLD": "PFLD 1 Probe \n No Trim",
        "RSS+2PFLD": "PFLD RTT Probe \n No Trim",
        "RSS without PFLD": "RSS \n No Trim",
        "RSS without PFLD+BitMap": "RSS BitMap\n No Trim",
        "RSS without PFLD - Yes Trimming": "RSS \n Yes Trim"
    }
    return [mapping.get(lbl, lbl) for lbl in labels]

# helper to run one (cfg, seed) and return (name, runtime)
def run_simulation(cfg, seed):
    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = os.path.join(tmpdir, "data")
        log_file = os.path.join(tmpdir, f"log_seed_{seed}.dat")
        cmd = common_args + ["-seed", str(seed), "-end", "100000", "-load_balancing_algo", cfg["algo"]]
        if cfg["disable_trim"]:
            cmd += ["-disable_trim"]
        if cfg["rss_params"]:
            cmd += ["-rss_parameters"] + cfg["rss_params"]
        if "+PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "1",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+2PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "0",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+BitMap" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-no_droping_low_header",
                "-pflr_proactive_probe", str(-1),
            ]
        cmd += ["-data_collection_dir", data_dir, "-o", log_file]

        # debug: show the exact command to be executed
        print("Executing command:", " ".join(cmd))
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if log_dir:
            # save raw stdout for this run
            outfn = os.path.join(log_dir, f"{cfg['name']}_seed_{seed}.log")
            with open(outfn, 'w') as lf:
                lf.write(res.stdout)
        # try primary parse
        times = re.findall(r"Maximum finishing time at host \d+:\s+(\d+)", res.stdout)
        if not times:
            # fallback to parse lines like "progress: 9 % (482564) - 91042255"
            times = re.findall(r"progress:\s*\d+\s*%\s*\(\d+\)\s*-\s*(\d+)", res.stdout)
            if not times:
                raise RuntimeError(f"could not parse runtime for {cfg['name']} (seed {seed})")
        return cfg["name"], max(float(t) for t in times)

# replace nested loops with a pool of workers
tasks = [(cfg, seed) for cfg in algorithm_configs for seed in range(1, iterations + 1)]
with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
    for name, runtime in executor.map(lambda t: run_simulation(t[0], t[1]), tasks):
        runtimes[name].append(runtime)

# Colors palette and per-bar color mapping by trimming status
colors = ["#262636", "#7e2c40", "#a42f44", "#d85034",
          "#ee8143", "#228a8d", "#145a5c", "#45448b",
          "#7c7ae6", "#3885cf"]
bar_colors = [colors[1] if not cfg["disable_trim"] else colors[0] for cfg in algorithm_configs]

# Create bar plot (single run per algorithm)
plt.figure(figsize=(8, 6))
values = [runtimes[name][0] if len(runtimes[name]) > 0 else 0 for name in algorithms]
x = range(len(algorithms))
bars = plt.bar(x, values, color=bar_colors)
plt.xticks(x, rename_xlabels(algorithms), fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Labels and title
plt.xlabel("Algorithm", fontsize=16)
plt.ylabel("Runtime (us)", fontsize=16)
plt.title("LLama 7B Runtime Per Iteration", fontsize=18)

# Annotate bars with values
for rect, val in zip(bars, values):
    plt.text(rect.get_x() + rect.get_width() / 2, rect.get_height(), f"{val:.0f}",
             ha='center', va='bottom', fontsize=10)

# Annotate PFLD bars with improvement vs "RSS without PFLD"
baseline_name = "RSS without PFLD"
try:
    baseline_idx = algorithms.index(baseline_name)
    baseline_val = values[baseline_idx]
except ValueError:
    baseline_val = None

if baseline_val is not None and baseline_val > 0:
    ymax = max(values) if values else 0
    offset = (0.03 * ymax) if ymax > 0 else 1.0
    for rect, name, val in zip(bars, algorithms, values):
        # PFLD runs only: "RSS+PFLD" and "RSS+2PFLD"
        is_pfld = (name == "RSS+PFLD") or (name == "RSS+2PFLD")
        if is_pfld:
            improvement_pct = (baseline_val - val) / baseline_val * 100.0
            plt.text(
                rect.get_x() + rect.get_width() / 2,
                rect.get_height() + offset,
                f"{improvement_pct:+.1f}%",
                ha='center',
                va='bottom',
                fontsize=10,
                color='tab:green' if improvement_pct >= 0 else 'tab:red'
            )

plt.tight_layout()
plt.savefig(args.output, dpi=300)
plt.show()