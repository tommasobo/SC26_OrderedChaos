import subprocess
import re
import tempfile
import os
import matplotlib.pyplot as plt
import argparse

plt.rcParams.update({'font.size': 14})

# parse rto_ratio and iterations from CLI
parser = argparse.ArgumentParser(description="Run htsim and plot runtimes")
parser.add_argument('--iterations', type=int, default=1,
                    help='Number of simulator iterations')
parser.add_argument('--rto_ratio', type=int, default=2,
                    help='RTO ratio for simulator')
parser.add_argument('--switch_random_drop_prob', type=float, default=0.005,
                    help='Switch random drop probability')
args = parser.parse_args()
iterations = args.iterations
rto_ratio = str(args.rto_ratio)
switch_random_drop_prob = str(args.switch_random_drop_prob)

# define the algorithms and how to invoke them
algorithm_configs = [
    {"name": "REPS with trimming", "algo": "reps", "disable_trim": False, "rss_params": None},
    {"name": "RSS+PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+2PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS without PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS without PFLD+BitMap", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS without PFLD - Yes Trimming", "algo": "rss", "disable_trim": False, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
]
algorithms = [cfg["name"] for cfg in algorithm_configs]

def rename_xlabels(labels):
    # Dummy mapping; replace values as needed
    mapping = {
        "REPS with trimming": "REPS \n Yes Trim",
        "RSS+PFLD": "PFLD 1 Probe \n No Trim",
        "RSS+2PFLD": "PFLD RTT Probe \n No Trim",
        "RSS without PFLD": "RSS \n No Trim",
        "RSS without PFLD+BitMap": "RSS BitMap\n No Trim",
        "RSS without PFLD - Yes Trimming": "RSS \n Yes Trim"
    }
    return [mapping.get(lbl, lbl) for lbl in labels]

# Create dict to store runtimes for each algorithm
runtimes = {name: [] for name in algorithms}

# common simulator args (no -end here)
htsim = "/home/a-tobonato/M/msft-htsim/build/htsim_uec"
data_cfg = "/home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json"
goal = "/home/a-tobonato/M/msft-htsim/sim/lgs/dlrm_N4_GPU4_300GB.bin"
topo = "/home/a-tobonato/M/msft-htsim/scripts/topologies/topo=fat_tree:over_sub=1:nodes=16:link_speed_gbps=400.topo"
common_args = [
    htsim, "-data_collection_config", data_cfg, # -end removed
    "-goal", goal, "-topo", topo, "-q", "75", "-cwnd", "151", "-mtu", "4160",
    "-sack_threshold", "0", "-ecn", "38", "113",
    "-switch_random_drop_prob", switch_random_drop_prob,
    "-linkspeed", "400000", "-sender_cc_only", "-sender_cc_algo", "dctcp",
    "-nodes", "128",
    "-iterations", str(1), "-rto_ratio", rto_ratio
]

# run each config and parse its max finishing time
for cfg in algorithm_configs:
    for seed in range(1, iterations + 1):
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            log_file = os.path.join(tmpdir, f"log_seed_{seed}.dat")
            # add -end here, not via Python args
            cmd = common_args + ["-seed", str(seed), "-end", "100000", "-load_balancing_algo", cfg["algo"]]
            if cfg["disable_trim"]:
                cmd += ["-disable_trim"]
            if cfg["rss_params"]:
                cmd += ["-rss_parameters"] + cfg["rss_params"]
            # if this is the RSS+PFLD config, add PFLD flags
            if "+PFLD" in cfg["name"]:
                cmd += [
                    "-precisefastlossrecovery", "3",
                    "-pflr_proactive_probe", "1",
                    "-pflr_proactive_rtx_probe",
                    "-no_droping_low_header"
                ]
            if "+2PFLD" in cfg["name"]:
                cmd += [
                    "-precisefastlossrecovery", "3",
                    "-pflr_proactive_probe", "0",
                    "-pflr_proactive_rtx_probe",
                    "-no_droping_low_header"
                ]
            if "+BitMap" in cfg["name"]:
                cmd += [
                    "-precisefastlossrecovery", "3",
                    "-no_droping_low_header",
                    "-pflr_proactive_probe", str(-1),
                ]
            cmd += ["-data_collection_dir", data_dir, "-o", log_file]

            # debug: show the exact command to be executed
            print("Executing command:", " ".join(cmd))
            res = subprocess.run(cmd, capture_output=True, text=True, check=True)
            times = re.findall(r"Maximum finishing time at host \d+:\s+(\d+)", res.stdout)
            if not times:
                raise RuntimeError(f"could not parse runtime for {cfg['name']} (seed {seed})")
            runtimes[cfg["name"]].append(max(float(t) for t in times))

# Create violin plot
plt.figure(figsize=(8, 6))
data = [runtimes[name] for name in algorithms]
vp = plt.violinplot(data, showmeans=True)

# Color by trimming status
colors = ["#262636", "#7e2c40", "#a42f44", "#d85034",
          "#ee8143", "#228a8d", "#145a5c", "#45448b",
          "#7c7ae6", "#3885cf"]
# True => trimming enabled, False => no trimming
trim_enabled = {cfg["name"]: (not cfg["disable_trim"]) for cfg in algorithm_configs}
for i, body in enumerate(vp["bodies"]):
    is_trim = trim_enabled[algorithms[i]]
    c = colors[1] if is_trim else colors[0]
    body.set_facecolor(c)
    body.set_edgecolor(c)
    body.set_alpha(0.85)

# Make internal violin lines black
for key in ("cmeans", "cmins", "cmaxes", "cbars", "cmedians", "cquantiles"):
    if key in vp:
        try:
            vp[key].set_color("black")
            vp[key].set_linewidth(1.2)
        except Exception:
            # Some backends may return a list of artists
            for artist in vp[key]:
                artist.set_color("black")
                artist.set_linewidth(1.2)

# Annotate PFLD improvement vs worst "RSS without PFLD"
ax = plt.gca()
baseline_key = "RSS without PFLD"
if baseline_key in runtimes and runtimes[baseline_key]:
    baseline_worst = max(runtimes[baseline_key])
    if baseline_worst > 0:
        all_vals = [v for vals in runtimes.values() for v in vals]
        if all_vals:
            y_min_all, y_max_all = min(all_vals), max(all_vals)
            # Add a little headroom for text labels
            headroom = 0.08 * (y_max_all - y_min_all) if y_max_all > y_min_all else 1.0
            ax.set_ylim(top=y_max_all + headroom)

            name_to_x = {name: i + 1 for i, name in enumerate(algorithms)}
            for name in algorithms:
                if "+PFLD" in name and runtimes.get(name):
                    best = min(runtimes[name])
                    improvement = (baseline_worst - best) / baseline_worst * 100.0
                    x = name_to_x[name]
                    y_local_max = max(runtimes[name])
                    y = y_local_max + 0.03 * (y_max_all - y_min_all) if y_max_all > y_min_all else y_local_max + 1.0
                    ax.text(x, y, f"{improvement:.1f}%", ha="center", va="bottom", fontsize=10, color="black")

plt.xticks(range(1, len(algorithms) + 1), rename_xlabels(algorithms), fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Labels and title
plt.xlabel("Algorithm Combination", fontsize=16)
plt.ylabel("Runtime (ms)", fontsize=16)
plt.title("DLRM Runtime Per Iteration - 100 Runs", fontsize=18)

plt.tight_layout()
plt.savefig("dlrm_runtime_per_iteration_violin_5.png", dpi=300)
plt.show()