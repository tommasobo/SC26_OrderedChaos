import os
import re
import argparse
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch

def parse_max_fct(file_path):
    """Scan the file for 'finished at X' and return the max X."""
    pattern = re.compile(r'finished at ([0-9.]+)')
    max_t = 0.0
    # ignore invalid UTF-8 bytes when reading
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            m = pattern.search(line)
            if m:
                t = float(m.group(1))
                if t > max_t:
                    max_t = t
    return max_t

# add a rename map for visualization
RENAME_MAP = {
    "pfld2_no_trim": "PFLD (Probe every 16) -\nNo Trim",
    "pfld1_no_trim": "PFLD16 (Probe every 1) -\nNo Trim",
    "pfld0_no_trim": "PFLD16 (Probe every RTT) -\nNo Trim",
    "pfld3_no_trim": "PFLD16 (Probe only msg end) -\nNo Trim",
    "ecmp_no_trim": "ECMP - No Trim",
    "ecmp2_no_trim": "ECMP - No Trim - NACK PSN gap",
    "ecmp_trim": "ECMP - Yes Trim",
    "flowbender_no_trim": "FlowBender - No Trim",
    "flowbender2_no_trim": "FlowBender - No Trim - NACK PSN gap",
    "flowbender_trim": "FlowBender - Yes Trim",    
    "reps_no_trim": "REPS - No Trim",
    "reps_trim": "REPS - Yes Trim",    
    "rps_no_trim": "RPS - No Trim",
    "rps_trim": "RPS - Yes Trim",    
    "pfld1_trim": "RSS - Yes Trim",   
    "rss_no_trim": "RSS - No Trim",
    "rss2_no_trim": "RSS - No Trim - NACK PSN gap",
}

def main():
    p = argparse.ArgumentParser(
        description="Plot max flow completion time per LB+trim setting (violin)"
    )
    p.add_argument("--results_dir",
                   help="Base directory containing one sub-folder per run")
    p.add_argument("-o", "--output",
                   default="max_fct_violin.png",
                   help="Filename for the saved violin plot")
    p.add_argument("--show", action="store_true",
                   help="Show the plot interactively after saving")
    args = p.parse_args()

    labels = []
    all_values = []
    # our palette
    colors = ["#262636", "#7e2c40", "#a42f44", "#d85034", 
              "#ee8143", "#228a8d", "#145a5c", "#45448b", 
              "#7c7ae6", "#3885cf"]
    all_colors = []

    # each subfolder corresponds to one run
    for sub in sorted(os.listdir(args.results_dir)):
        # drop the entire “pfld2_trim” run
        if sub == "pfld2_trim" or sub == "pfld0_trim" or sub == "pfld3_trim":
            continue
        # apply rename if needed
        label = RENAME_MAP.get(sub, sub)
        subdir = os.path.join(args.results_dir, sub)
        if not os.path.isdir(subdir):
            continue

        # pick color: first color if “no_trim” in sub else second
        color = colors[0] if "no_trim" in sub else colors[1]

        # gather all seed files
        seed_files = [fn for fn in os.listdir(subdir)
                      if fn.startswith("log_seed_") and fn.endswith(".out")]
        if not seed_files:
            print(f"⚠️  no log_seed_*.dat in {subdir}, skipping")
            continue

        # parse max_fct for each seed
        seed_vals = [parse_max_fct(os.path.join(subdir, fn))
                     for fn in seed_files]

        labels.append(label)
        all_values.append(seed_vals)
        all_colors.append(color)

    # rename labels for display
    labels = [RENAME_MAP.get(lbl, lbl) for lbl in labels]

    # sort everything alphabetically by the mapped label
    items = list(zip(labels, all_values, all_colors))
    items.sort(key=lambda x: x[0])
    labels, all_values, all_colors = zip(*items)
    labels = list(labels)
    all_values = list(all_values)
    all_colors = list(all_colors)

    # violin plot
    plt.figure(figsize=(10,6))
    parts = plt.violinplot(
        all_values,
        showmeans=False,
        showmedians=True,
        showextrema=True
    )

    # color each violin body
    for body, col in zip(parts['bodies'], all_colors):
        body.set_facecolor(col)
        body.set_edgecolor('black')
        body.set_alpha(0.7)

    # color the interior lines (min/max caps + median line)
    for coll_name in ('cmins', 'cmaxes', 'cmedians', 'cbars'):
        lc = parts.get(coll_name)
        if lc is not None:
            # assign each segment the matching violin color
            lc.set_color(all_colors)
            lc.set_linewidth(1.0)
            lc.set_zorder(5)

    plt.xticks(range(1, len(labels)+1), labels, rotation=45, ha='right')
    plt.xlabel("Algorithm_Trim")
    plt.ylabel("Max Flow Completion Time")
    plt.title("Max FCT per LoadBalancing Algo & Trimming Mode - 100 Runs (Min, Mean, Max) - No Random Drops")
    #plt.ylim(65,100)

    # compute and overlay 99th percentile
    p99 = [np.percentile(vals, 99) for vals in all_values]
    xs  = range(1, len(labels) + 1)
    # draw 99th-pct as black X’s on top
    h99 = plt.scatter(xs, p99,
                     color='black',
                     marker='x',
                     label='99th percentile',
                     zorder=10)

    # add legend entries for trimming colors
    patch_no = Patch(facecolor=colors[0],
                     edgecolor='black',
                     alpha=0.7,
                     label='Without Trimming')
    patch_yes = Patch(facecolor=colors[1],
                      edgecolor='black',
                      alpha=0.7,
                      label='With Trimming')
    plt.legend(handles=[patch_no, patch_yes, h99],
               loc='upper right')

    # annotate min, mean and max (no decimals) on top of each violin
    global_min = min(min(v) for v in all_values)
    global_max = max(max(v) for v in all_values)
    y_offset = (global_max - global_min) * 0.03
    for idx, vals in enumerate(all_values):
        mi, me, ma = min(vals), np.mean(vals), max(vals)
        txt = f"{mi:.0f},{me:.0f},{ma:.0f}"
        plt.text(idx + 1, ma + y_offset, txt,
                 ha='center', va='bottom', fontsize=7.3)

    # add some whitespace at top so annotations don't overlap border
    bottom, top = plt.ylim()
    plt.ylim(bottom, global_max + y_offset * 5)

    plt.tight_layout()
    plt.savefig(args.output)
    print(f"Saved violin plot to {args.output}")
    if args.show:
        plt.show()

if __name__ == "__main__":
    main()