import subprocess
import re
import tempfile
import os
import matplotlib.pyplot as plt
import argparse
import concurrent.futures      # added for parallel runs

plt.rcParams.update({'font.size': 14})

# parse rto_ratio and iterations from CLI
parser = argparse.ArgumentParser(description="Run htsim and plot runtimes")
parser.add_argument('--iterations', type=int, default=1,
                    help='Number of simulator iterations')
parser.add_argument('--rto_ratio', type=int, default=1,
                    help='RTO ratio for simulator')
parser.add_argument('--fail_psn', type=int, default=-1,
                    help='RTO ratio for simulator')
parser.add_argument('--switch_random_drop_prob', type=float, default=0.0,
                    help='Switch random drop probability')
parser.add_argument('--workers', type=int, default=os.cpu_count(),
                    help='Number of parallel workers')
parser.add_argument('--log_dir', type=str, default="testing",
                    help='Directory to save simulator stdout logs')
parser.add_argument('--output', type=str, default="dlrm_runtime_per_iteration_bar.png",
                    help='Output image filename')
args = parser.parse_args()
iterations = args.iterations
rto_ratio = str(args.rto_ratio)
switch_random_drop_prob = str(args.switch_random_drop_prob)
workers = args.workers
log_dir = args.log_dir
if log_dir:
    os.makedirs(log_dir, exist_ok=True)

# define the algorithms and how to invoke them
algorithm_configs = [
    {"name": "RSS+PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+1PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+2PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+3PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
    {"name": "RSS+4PFLD", "algo": "rss", "disable_trim": True, "rss_params": ["mean_rtt", "16", "0.1", "0", "0", "25"]},
]
algorithms = [cfg["name"] for cfg in algorithm_configs]

# Create dict to store runtimes for each algorithm
runtimes = {name: [] for name in algorithms}

# NEW: store lost packet counts per algorithm
lost_packets = {name: [] for name in algorithms}

# common simulator args (no -end here)
htsim = "/home/a-tobonato/M/msft-htsim/build/htsim_uec"
data_cfg = "/home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json"
goal = "/home/a-tobonato/M/msft-htsim/scripts/connection_matrices_old/allreduce_8.cm"
topo = "/home/a-tobonato/M/msft-htsim/scripts/topologies/topo=fat_tree:over_sub=1:nodes=128:link_speed_gbps=400.topo"
common_args = [
    htsim, "-data_collection_config", data_cfg, # -end removed
    "-tm", goal, "-topo", topo, "-q", "75", "-cwnd", "151", "-mtu", "4160",
    "-sack_threshold", "0", "-ecn", "38", "113",
    "-switch_random_drop_prob", switch_random_drop_prob,
    "-linkspeed", "400000",
    "-nodes", "128",
    "-sender_cc_only",
    "-fail_psn", str(args.fail_psn),
    "-sender_cc_algo", "dctcp",
    "-iterations", str(1), "-rto_ratio", rto_ratio, "-lgs_percent", str(18)
]

def rename_xlabels(labels):
    # Dummy mapping; replace values as needed
    mapping = {
        "RSS+PFLD": "PFLD 16 Probe \n No Trim",
        "RSS+1PFLD": "PFLD 1 Probe \n No Trim",
        "RSS+2PFLD": "PFLD 2 Probe \n No Trim",
        "RSS+3PFLD": "PFLD 8 Probe \n No Trim",
        "RSS+4PFLD": "PFLD End Msg \n No Trim",
    }
    return [mapping.get(lbl, lbl) for lbl in labels]

def _count_lost_packets_from_stdout(stdout):
    # Updated to search directly in the stdout output
    return len(re.findall(r"^Dropping packet PSN.*$", stdout, re.MULTILINE))

def _filter_worst_5_percent(data):
    """Remove the worst 5% of values from the data."""
    if not data:
        return data
    cutoff_index = int(len(data) * 0.95)
    return sorted(data)[:cutoff_index]

# helper to run one (cfg, seed) and return (name, runtime)
def run_simulation(cfg, seed):
    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = os.path.join(tmpdir, "data")
        log_file = os.path.join(tmpdir, f"log_seed_{seed}.dat")
        cmd = common_args + ["-seed", str(seed), "-end", "100000", "-load_balancing_algo", cfg["algo"]]
        if cfg["disable_trim"]:
            cmd += ["-disable_trim"]
        if cfg["rss_params"]:
            cmd += ["-rss_parameters"] + cfg["rss_params"]
        if "+PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "16",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+1PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "1",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+2PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "2",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+3PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "8",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        if "+4PFLD" in cfg["name"]:
            cmd += [
                "-precisefastlossrecovery", "3",
                "-pflr_proactive_probe", "-1",
                "-pflr_proactive_rtx_probe",
                "-no_droping_low_header"
            ]
        cmd += ["-data_collection_dir", data_dir, "-o", log_file]

        print("Executing command:", " ".join(cmd))
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        if log_dir:
            outfn = os.path.join(log_dir, f"{cfg['name']}_seed_{seed}.log")
            with open(outfn, 'w') as lf:
                lf.write(res.stdout)

        # Count lost packets directly from stdout
        lost = _count_lost_packets_from_stdout(res.stdout)

        # try primary parse
        times = re.findall(r"Maximum finishing time at host \d+:\s+(\d+)", res.stdout)
        if not times:
            # fallback to parse lines like "progress: 9 % (482564) - 91042255"
            times = re.findall(r"progress:\s*\d+\s*%\s*\(\d+\)\s*-\s*(\d+)", res.stdout)
            if not times:
                # NEW fallback: parse "current time <ps>" from flow lines; convert ps -> us
                ps_times = re.findall(r"\bcurrent time\s+(\d+)", res.stdout)
                if ps_times:
                    return cfg["name"], max(float(t) for t in ps_times) / 1e6, lost
                raise RuntimeError(f"could not parse runtime for {cfg['name']} (seed {seed})")
        return cfg["name"], max(float(t) for t in times), lost

# replace nested loops with a pool of workers
tasks = [(cfg, seed) for cfg in algorithm_configs for seed in range(1, iterations + 1)]
with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
    for name, runtime, lost in executor.map(lambda t: run_simulation(t[0], t[1]), tasks):
        runtimes[name].append(runtime)
        lost_packets[name].append(lost)

# Colors palette and per-bar color mapping by trimming status
colors = ["#262636", "#7e2c40", "#a42f44", "#d85034",
          "#ee8143", "#228a8d", "#145a5c", "#45448b",
          "#7c7ae6", "#3885cf"]
bar_colors = [colors[1] if not cfg["disable_trim"] else colors[0] for cfg in algorithm_configs]

# Create violin plot of per-seed completion times (one violin per algorithm)
filtered = [(name, _filter_worst_5_percent(runtimes[name])) for name in algorithms if len(runtimes[name]) > 0]
if not filtered:
    raise RuntimeError("No runtimes collected to plot.")

plot_names, plot_data = zip(*filtered)

# Map colors for filtered algorithms (by trimming status)
name_to_cfg = {cfg["name"]: cfg for cfg in algorithm_configs}
plot_colors = [colors[1] if not name_to_cfg[n]["disable_trim"] else colors[0] for n in plot_names]

plt.figure(figsize=(8, 6))
parts = plt.violinplot(plot_data, showmeans=False, showmedians=True, showextrema=False)

# Style violins
for i, body in enumerate(parts['bodies']):
    body.set_facecolor(plot_colors[i])
    body.set_edgecolor("black")
    body.set_alpha(0.7)
if 'cmedians' in parts:
    parts['cmedians'].set_edgecolor('black')
    parts['cmedians'].set_linewidth(1.5)

# X-axis positions are 1..N for matplotlib.violinplot
positions = range(1, len(plot_names) + 1)
plt.xticks(positions, rename_xlabels(list(plot_names)), fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Labels and title
plt.xlabel("Algorithm", fontsize=16)
plt.ylabel("Runtime (us)", fontsize=16)
plt.title("Ring AllReduce, varying seed", fontsize=18)

plt.tight_layout()
plt.savefig(args.output, dpi=300)
#plt.show()

# NEW: Lost packets violin plot
lost_filtered = [(name, lost_packets[name]) for name in algorithms if len(lost_packets[name]) > 0]
if lost_filtered:
    lost_names, lost_data = zip(*lost_filtered)
    plt.figure(figsize=(8, 6))
    parts = plt.violinplot(lost_data, showmeans=False, showmedians=True, showextrema=False)
    for i, body in enumerate(parts['bodies']):
        body.set_facecolor(plot_colors[i])
        body.set_edgecolor("black")
        body.set_alpha(0.7)
    if 'cmedians' in parts:
        parts['cmedians'].set_edgecolor('black')
        parts['cmedians'].set_linewidth(1.5)
    positions = range(1, len(lost_names) + 1)
    plt.xticks(positions, rename_xlabels(list(lost_names)), fontsize=10)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.xlabel("Algorithm", fontsize=16)
    plt.ylabel("Lost packets (count)", fontsize=16)
    plt.title("Ring AllReduce, lost packets per run", fontsize=18)
    plt.tight_layout()
    plt.savefig("lost_packets_violin.png", dpi=300)
    #plt.show()