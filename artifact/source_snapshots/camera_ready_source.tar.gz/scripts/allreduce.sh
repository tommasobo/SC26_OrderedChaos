#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"

time python3 "$SCRIPT_DIR/plot_collective_violin_custom.py" --workers 3 --log_dir allred_3_1 --switch_random_drop_prob 0.001 --rto_ratio 2 --iterations 15 --output allred_31.png

time python3 "$SCRIPT_DIR/plot_collective_violin_custom.py" --workers 3 --log_dir allred_4_1 --switch_random_drop_prob 0.0001 --rto_ratio 2 --iterations 15 --output allred_41.png

time python3 "$SCRIPT_DIR/plot_collective_violin_custom.py" --workers 3 --log_dir allred_5_1 --switch_random_drop_prob 0.00001 --rto_ratio 2 --iterations 15 --output allred_51.png