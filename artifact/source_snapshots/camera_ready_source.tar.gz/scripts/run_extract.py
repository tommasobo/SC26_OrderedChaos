import os
import re
import argparse
import matplotlib.pyplot as plt

def parse_max_fct(file_path):
    """Scan the file for 'finished at X' and return the max X."""
    pattern = re.compile(r'finished at ([0-9.]+)')
    max_t = 0.0
    with open(file_path, 'r') as f:
        for line in f:
            m = pattern.search(line)
            if m:
                t = float(m.group(1))
                if t > max_t:
                    max_t = t
    return max_t

def main():
    p = argparse.ArgumentParser(
        description="Plot max flow completion time per LB+trim setting"
    )
    p.add_argument("--results_dir",
                   help="Base directory containing one sub-folder per run")
    p.add_argument("-o", "--output",
                   default="max_fct_bar.png",
                   help="Filename for the saved bar plot")
    args = p.parse_args()

    labels = []
    values = []

    # each subfolder corresponds to one run
    for sub in sorted(os.listdir(args.results_dir)):
        subdir = os.path.join(args.results_dir, sub)
        if not os.path.isdir(subdir):
            continue
        # find the output_*.txt file
        out_txt = None
        for fn in os.listdir(subdir):
            if fn.startswith("output_") and fn.endswith(".txt"):
                out_txt = os.path.join(subdir, fn)
                break
        if out_txt is None:
            print(f"⚠️  no output_*.txt in {subdir}, skipping")
            continue

        max_fct = parse_max_fct(out_txt)
        labels.append(sub)
        values.append(max_fct)

    # plot
    plt.figure(figsize=(10,6))
    bars = plt.bar(labels, values, color='skyblue')
    plt.xticks(rotation=45, ha='right')
    plt.xlabel("Algorithm_Trim")
    plt.ylabel("Max Flow Completion Time")
    plt.title("Max FCT per Load‐Balancing Algo & Trimming")

    # add value labels on top of each bar
    for bar in bars:
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            height,
            f"{height:.2f}",
            ha='center',
            va='bottom'
        )

    plt.tight_layout()
    plt.savefig(args.output)
    print(f"Saved bar‐plot to {args.output}")
    plt.show()

if __name__ == "__main__":
    main()