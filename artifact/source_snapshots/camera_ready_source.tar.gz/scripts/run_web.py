import os
import subprocess
import concurrent.futures
import argparse


lb_algos = ["pfld0", "pfld1", "pfld2", "pfld3", "apfld4_1", "apfld5_2", "ecmp", "rps", "flowbender", "reps"]
lb_algos = ["pfld0", "pfld1", "pfld2", "pfld3", "ecmp", "ecmp2", "rps", "flowbender",  "flowbender2", "reps" , "rss", "rss2"]

trimming = [False, True]


def getLBCmdLine(input_name):
    return "oblivious" if input_name == "rps" else input_name


def getTrimmingFlag(trim):
    # in htsim: -disable_trim turns trimming OFF
    return "" if trim else "-disable_trim"


def make_cmd(algo, trim, base_out_dir, seed, exp_name):
    # pick actual lb string
    lb = getLBCmdLine(algo)
    if algo.startswith("pfld"):
        lb = "rss"
    elif algo.startswith("apfld"):
        lb = "rss"

    probe_every = 1
    if algo == "pfld1":
        probe_every = 1
    elif algo == "pfld2":
        probe_every = 16
    elif algo == "pfld0":
        probe_every = 0
    elif algo == "pfld3":
        probe_every = -1

    trim_flag = getTrimmingFlag(trim)

    # no more seed subfolder—just algo_trim
    out_dir = os.path.join(
        base_out_dir,
        f"{algo}_{'trim' if trim else 'no_trim'}"
    )
    os.makedirs(out_dir, exist_ok=True)

    cmd = [
        "/home/a-tobonato/M/msft-htsim/build/htsim_uec",
        "-data_collection_config",
        "/home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json",
        "-end", "10000",
        "-seed", str(seed),
        "-tm", "/home/a-tobonato/M/msft-htsim/scripts/connection_matrices/{exp_name}".format(exp_name=exp_name),
        "-topo", "/home/a-tobonato/M/msft-htsim/scripts/topologies/topo=fat_tree:over_sub=2:nodes=128:link_speed_gbps=400.topo",
        "-q", "75",
        "-cwnd", "151",
        "-mtu", "4160",
        "-sack_threshold", "0",
        "-ecn", "38", "113",
        "-switch_random_drop_prob", "0.001",
        "-load_balancing_algo", lb,
    ]
    # PFLD‐only flags
    if algo.startswith("pfld") and not trim:
        cmd += [
            "-precisefastlossrecovery", "3",
            "-pflr_proactive_probe", str(probe_every),
            "-pflr_proactive_rtx_probe",
            "-no_droping_low_header",
        ]
    elif algo.startswith("ecmp") and not trim:
        cmd += [
            "-precisefastlossrecovery", "1",
            "-no_droping_low_header",
        ]
    elif algo.startswith("apfld4_1") and not trim:
        cmd += [
            "-precisefastlossrecovery", "0",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(0),
        ]
    elif algo.startswith("apfld5_2") and not trim:
        cmd += [
            "-precisefastlossrecovery", "1",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(0),
        ]
    elif algo.startswith("apfld6_3") and not trim:
        cmd += [
            "-precisefastlossrecovery", "2",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(0),
        ]
    elif algo.startswith("flowbender") and not trim:
        cmd += [
            "-precisefastlossrecovery", "1",
            "-no_droping_low_header",
        ]
    elif algo.startswith("pfld") and trim:
        cmd += ["-no_droping_low_header"]

    cmd += [
        "-linkspeed", "400000",
        "-rss_parameters", "mean_rtt", "16", "0.1", "0", "0", "25",
        "-sender_cc_only",
        "-sender_cc_algo", "dctcp",
        trim_flag,
        "-data_collection_dir", out_dir,
        # include seed in the log filename
        "-o", f"{out_dir}/log_seed_{seed}.dat",
    ]
    return [p for p in cmd if p]


def run(cmd):
    # simulator data file (via '-o') - leave it for the sim to write
    data_file = cmd[-1]
    out_dir = os.path.dirname(data_file)
    algo, trimflag = os.path.basename(out_dir).split('_', 1)

    # create a separate .out log
    log_file = os.path.splitext(data_file)[0] + ".out"

    # header for the log
    header = (
        f"# Configuration\n"
        f"load_balancing = {algo}\n"
        f"trimming      = {'ON' if trimflag=='trim' else 'OFF'}\n\n"
    )

    print("Running:", " ".join(cmd), ">", log_file)

    # write header and capture stdout/stderr into .out
    with open(log_file, "w") as f_log:
        f_log.write(header)
        p = subprocess.Popen(cmd, stdout=f_log, stderr=subprocess.STDOUT, text=True)
        ret = p.wait()

    if ret != 0:
        print(f"→ FAILED (code={ret}) in {out_dir}")
        print("Command:", " ".join(cmd))

    return ret


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run htsim experiments in parallel for various LB algos and trimming."
    )
    parser.add_argument(
        "--output_dir", "-o",
        required=True,
        help="Base directory where per‐run output folders will be created."
    )
    parser.add_argument(
        "--exp_name", "-e",
        required=True,
        help="Name of the experiment (.cm file)."
    )
    parser.add_argument(
        "--jobs", "-j",
        type=int,
        default=None,
        help="Number of parallel processes (defaults to number of CPUs)"
    )
    parser.add_argument(
        "--runs", "-n",
        type=int,
        default=1,
        help="How many times to rerun each config (with different seeds)"
    )
    args = parser.parse_args()

    max_workers = args.jobs or os.cpu_count()

    seeds = range(1, args.runs + 1)
    cmds = [
        make_cmd(algo, trim, args.output_dir, seed, args.exp_name)
        for algo in lb_algos
        for trim in trimming
        for seed in seeds
    ]

    failed = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as pool:
        # submit all jobs and track failures
        futures = {pool.submit(run, cmd): cmd for cmd in cmds}
        for future in concurrent.futures.as_completed(futures):
            cmd = futures[future]
            ret = future.result()
            if ret != 0:
                failed.append(cmd)

    # report any failed jobs after completion
    if failed:
        print("The following jobs failed:")
        for cmd in failed:
            print(" ".join(cmd))