#!/usr/bin/env bash
set -euo pipefail

# ------------------------------------------------------------------
# CONFIGURABLE SETTINGS (override on the command line if desired)
# ------------------------------------------------------------------
JOBS=${JOBS:-16}                       # Parallelism:  JOBS=16 ./run_all.sh
RESULTS_ROOT=${RESULTS_ROOT:-results_custom_no_os_smartt} # Output root: RESULTS_ROOT=my_runs ./run_all.sh
RUNS=${RUNS:-10}                     # Number of runs: override with RUNS env var
OS_RATIO=${OS_RATIO:-1}           # Oversubscription ratio: override with OS_RATIO env var
CC_ALGO=${CC_ALGO:-smartt_ecn_aifd}         # Congestion control algorithm: override with CC_ALGO env var

# Create the parent results directory (and any missing parents).
mkdir -p "$RESULTS_ROOT"

# Helper function to prefix an output dir with the root path
outdir() { echo "${RESULTS_ROOT}/$1"; }

# ------------------------------------------------------------------
# 1. RUN EXPERIMENTS
# ------------------------------------------------------------------

# ---------- one.cm ----------
#python3 run_compare.py --output_dir "$(outdir one_drops)"   --exp_name one.cm               --jobs "$JOBS" --runs "$RUNS" --corruption_rate 1     --drop_psn 30 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
#python3 run_compare.py --output_dir "$(outdir no_drops)"    --exp_name one.cm               --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"

# ---------- incast_8 ----------
#python3 run_compare.py --output_dir "$(outdir incast_8_512_no_drops)"  --exp_name incast_8_512.cm   --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
#python3 run_compare.py --output_dir "$(outdir incast_8_512_yes_drops)" --exp_name incast_8_512.cm   --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
#python3 run_compare.py --output_dir "$(outdir incast_8_2000_no_drops)"  --exp_name incast_8_2000.cm  --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
#python3 run_compare.py --output_dir "$(outdir incast_8_2000_yes_drops)" --exp_name incast_8_2000.cm  --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"

# ---------- incast_50 ----------
#python3 run_compare.py --output_dir "$(outdir incast_50_512_no_drops)"  --exp_name incast_50_512.cm  --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
#python3 run_compare.py --output_dir "$(outdir incast_50_512_yes_drops)" --exp_name incast_50_512.cm  --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"

# ---------- permutation ----------
python3 run_compare.py --output_dir "$(outdir perm_512_no_drops)"   --exp_name perm_128n_128c_512KB.cm --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir perm_512_yes_drops)"  --exp_name perm_128n_128c_512KB.cm --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir perm_2000_no_drops)"  --exp_name perm_128n_128c_2MB.cm   --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir perm_2000_yes_drops)" --exp_name perm_128n_128c_2MB.cm   --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"

# ------------------------------------------------------------------
# 2. PLOT RESULTS
# ------------------------------------------------------------------

results_dirs=(
  one_drops
  no_drops
  incast_8_512_no_drops
  incast_8_512_yes_drops
  incast_8_2000_no_drops
  incast_8_2000_yes_drops
  incast_50_512_no_drops
  incast_50_512_yes_drops
  perm_512_no_drops
  perm_512_yes_drops
  perm_2000_no_drops
  perm_2000_yes_drops
)

for dir in "${results_dirs[@]}"; do
  full_dir="$(outdir "$dir")"
  echo "Generating violin plot for $full_dir ..."
  python3 run_violin.py --results_dir "$full_dir" --output "$full_dir"
done

echo "✅ All experiments finished."
echo "📂 Results and plots live in: $RESULTS_ROOT"
