#!/bin/bash -eux

ALGO_FILE="/home/a-tobonato/M/msft-htsim/scripts/lb_algos_bg.txt"
SIZES=(128)
PERCENTAGE_BG=15

for SIZE in "${SIZES[@]}"; do

  printf "\n\n===== Running RSS experiments and plotting results: %s nodes =====\n\n" "$SIZE"

  # Baseline comparison (ecmp,rps,reps,rss)
  : > "$ALGO_FILE"
  echo "ecmp,rps,rss" > "$ALGO_FILE"
  python3 run_rss.py --topology_size "$SIZE" --jobs 2 --interval 10 --exp_name tornado --output_dir "rss_bg_${SIZE}_compare_tornado_2" --size_msg 2000000 --clean --percentage_bg "$PERCENTAGE_BG" --load_algo_file "$ALGO_FILE"
  python3 plot_rss_bg.py --results_dir "rss_bg_${SIZE}_compare_tornado_2" --output_dir "rss_bg_${SIZE}" --output rss_compare_tornado_2

  python3 run_rss.py --topology_size "$SIZE" --jobs 2 --interval 10 --exp_name tornado --output_dir "rss_bg_${SIZE}_compare_tornado_8" --size_msg 8000000 --clean --percentage_bg "$PERCENTAGE_BG" --load_algo_file "$ALGO_FILE"
  python3 plot_rss_bg.py --results_dir "rss_bg_${SIZE}_compare_tornado_8" --output_dir "rss_bg_${SIZE}" --output rss_compare_tornado_8
done