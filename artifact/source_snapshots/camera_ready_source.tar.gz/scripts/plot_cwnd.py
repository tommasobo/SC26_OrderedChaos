#!/usr/bin/env python3
"""
Script to plot congestion window (cwnd) evolution over time for each flow.
Usage:
    python plot_cwnd.py input_file [-o output_image]
"""
import argparse
import re
import matplotlib.pyplot as plt
from collections import defaultdict

def parse_args():
    parser = argparse.ArgumentParser(description='Plot cwnd vs time for flows')
    parser.add_argument('input_file', help='Path to the cwnd trace file')
    parser.add_argument('-o', '--output', help='Output image file (e.g., cwnd_plot.png)')
    return parser.parse_args()

def read_cwnd_trace(path):
    """
    Reads a trace file and extracts time and cwnd values per flow.
    Returns a dict: {flow_name: [(time, cwnd), ...], ...}
    """
    pattern = re.compile(r"Flow\s+(\S+)\s+-\s+Time\s+([0-9\.]+)\s+-\s+CWND\s+(\d+)")
    data = defaultdict(list)
    with open(path) as f:
        for line in f:
            m = pattern.search(line)
            if not m:
                continue
            flow, t_str, cwnd_str = m.groups()
            time = float(t_str)
            cwnd = int(cwnd_str)
            data[flow].append((time, cwnd))
    return data

def plot_cwnd(data, output_path=None):
    """
    Plots cwnd vs time for each flow in data.
    If output_path is given, saves the figure, else shows it interactively.
    """
    plt.figure(figsize=(10, 6))
    for flow, points in data.items():
        # sort by time
        points.sort(key=lambda x: x[0])
        times = [pt[0] for pt in points]
        cwnds = [pt[1] for pt in points]
        plt.plot(times, cwnds, label=flow)

    plt.xlabel('Time (s)')
    plt.ylabel('CWND')
    plt.title('Congestion Window Evolution')
    plt.legend(loc='best')
    plt.grid(True)
    plt.tight_layout()
    if output_path:
        plt.savefig(output_path)
        print(f"Plot saved to {output_path}")
    else:
        plt.show()


def main():
    args = parse_args()
    data = read_cwnd_trace(args.input_file)
    if not data:
        print(f"No cwnd entries found in {args.input_file}")
        return
    plot_cwnd(data, args.output)

if __name__ == '__main__':
    main()
