import re
import argparse
import numpy as np
import matplotlib.pyplot as plt

def parse_flow_sizes(logfile):
    sizes = []
    pattern = re.compile(r"finished.*total bytes (\d+)")
    with open(logfile) as f:
        for line in f:
            m = pattern.search(line)
            if m:
                sizes.append(int(m.group(1)))
    return sizes

def main():
    parser = argparse.ArgumentParser(
        description="Plot flow size distribution (bytes)"
    )
    parser.add_argument("--logfile", help="Path to log file")
    parser.add_argument("-o","--output",
                        help="Save plot to file instead of showing",
                        default=None)
    args = parser.parse_args()

    sizes = parse_flow_sizes(args.logfile)
    mtu = 4096
    total_packets = sum((size + mtu - 1) // mtu for size in sizes)
    print(f"Total packets sent across all flows: {total_packets}")
    # define bins: 0–4KiB, 4KiB–16KiB, then 3 equal-width bins from 16KiB up to max
    if sizes:
        max_size = max(sizes)
        # base edges
        bins = [0, 4096, 16384]
        # split [16KiB, max_size] into 3 bins → need 4 edges, drop first since it's 16KiB
        extra_edges = np.linspace(16384, max_size, num=4)[1:].tolist()
        bins.extend(extra_edges)
    else:
        bins = [0, 4096, 16384, 65536, 131072, 262144]

    bins = [0, 4096, 16384, 65536, 131072, 2621440, 4621440]
    # compute counts per bin and force empty bins to height=1
    counts, edges = np.histogram(sizes, bins=bins)
    # convert counts to percentages of total flows
    total_flows = len(sizes)
    if total_flows > 0:
        heights = counts / total_flows * 100.0
    else:
        heights = counts.astype(float)

    # draw evenly‐spaced bars
    x = np.arange(len(counts))
    plt.bar(x, heights, edgecolor="black", align="center")

    # label each bar with its byte‐range
    labels = [
        f"{int(edges[i]//1024)}KiB-{int(edges[i+1]//1024)}KiB"
        for i in range(len(edges)-1)
    ]
    plt.xticks(x, labels, rotation=45, ha="right")
    

    plt.xlabel("Flow size (bytes)")
    plt.ylabel("Percentage of flows (%)")
    plt.ylim(0, 100)
    plt.title("Flow Size Distribution")
    plt.tight_layout()
    if args.output:
        plt.savefig(args.output)
    else:
        plt.show()

if __name__ == "__main__":
    main()
