#!/usr/bin/env bash
set -euo pipefail

# ------------------------------------------------------------------
# CONFIGURABLE SETTINGS (override on the command line if desired)
# ------------------------------------------------------------------
JOBS=${JOBS:-8}                       # Parallelism:  JOBS=16 ./run_all.sh
RESULTS_ROOT=${RESULTS_ROOT:-results_custom_no_os} # Output root: RESULTS_ROOT=my_runs ./run_all.sh
RUNS=${RUNS:-30}                     # Number of runs: override with RUNS env var

# Create the parent results directory (and any missing parents).
mkdir -p "$RESULTS_ROOT"

# Helper function to prefix an output dir with the root path
outdir() { echo "${RESULTS_ROOT}/$1"; }

# ------------------------------------------------------------------
# 1. RUN EXPERIMENTS
# ------------------------------------------------------------------

# ---------- one.cm ----------

# ---------- incast_50 ----------
python3 run_compare.py --output_dir "$(outdir incast_8_2000_no_drops)"  --exp_name incast_8_2000.cm  --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0
python3 run_compare.py --output_dir "$(outdir incast_8_2000_yes_drops)" --exp_name incast_8_2000.cm  --jobs "$JOBS" --runs "$RUNS" --corruption_rate 0.001

# ------------------------------------------------------------------
# 2. PLOT RESULTS
# ------------------------------------------------------------------

results_dirs=(
  one_drops
  no_drops
  incast_8_512_no_drops
  incast_8_512_yes_drops
  incast_8_2000_no_drops
  incast_8_2000_yes_drops
  incast_50_512_no_drops
  incast_50_512_yes_drops
  perm_512_no_drops
  perm_512_yes_drops
  perm_2000_no_drops
  perm_2000_yes_drops
)

for dir in "${results_dirs[@]}"; do
  full_dir="$(outdir "$dir")"
  echo "Generating violin plot for $full_dir ..."
  python3 run_violin.py --results_dir "$full_dir" --output "$full_dir"
done

echo "✅ All experiments finished."
echo "📂 Results and plots live in: $RESULTS_ROOT"
