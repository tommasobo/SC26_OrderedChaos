#!/usr/bin/env bash
set -euo pipefail

# ------------------------------------------------------------------
# CONFIGURABLE SETTINGS (override on the command line if desired)
# ------------------------------------------------------------------
JOBS=${JOBS:-6}                       # Parallelism:  JOBS=16 ./run_all.sh
RESULTS_ROOT=${RESULTS_ROOT:-results_web_no_os_smartt} # Output root: RESULTS_ROOT=my_runs ./run_all.sh
RUNS=${RUNS:-1}                     # Number of runs: override with RUNS env var
OS_RATIO=${OS_RATIO:-1}           # Oversubscription ratio: override with OS_RATIO env var
CC_ALGO=${CC_ALGO:-smartt_ecn_aifd}         # Congestion control algorithm: override with CC_ALGO env var

# Create the parent results directory (and any missing parents).
mkdir -p "$RESULTS_ROOT"

# Helper function to prefix an output dir with the root path
outdir() { echo "${RESULTS_ROOT}/$1"; }

# ------------------------------------------------------------------
# 1. RUN EXPERIMENTS
# ------------------------------------------------------------------

# ---------- Ali Traces ----------
python3 run_compare.py --output_dir "$(outdir ali_small_no_drops)"  --exp_name ali_s_80.cm   --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir ali_small_yes_drops)" --exp_name ali_s_80.cm   --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir ali_large_no_drops)"  --exp_name ali_l_80.cm  --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir ali_large_yes_drops)" --exp_name ali_l_80.cm  --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"

# ---------- incast_50 ----------
# ---------- Web Traces ----------
python3 run_compare.py --output_dir "$(outdir web_small_no_drops)"  --exp_name web_s_80.cm   --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir web_small_yes_drops)" --exp_name web_s_80.cm   --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir web_large_no_drops)"  --exp_name web_l_80.cm  --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"
python3 run_compare.py --output_dir "$(outdir web_large_yes_drops)" --exp_name web_l_80.cm  --jobs "$JOBS" --runs "$RUNS" --clean --corruption_rate 0.001 --os_ratio "$OS_RATIO" --cc_algorithm "$CC_ALGO"


# ------------------------------------------------------------------
# 2. PLOT RESULTS
# ------------------------------------------------------------------

results_dirs=(
  ali_small_no_drops
  ali_small_yes_drops
  ali_large_no_drops
  ali_large_yes_drops
  web_small_no_drops
  web_small_yes_drops
  web_large_no_drops
  web_large_yes_drops
)

for dir in "${results_dirs[@]}"; do
  full_dir="$(outdir "$dir")"
  echo "Generating violin plot for $full_dir ..."
  python3 run_web_plot.py --divide_plots --results_dir "$full_dir" --output "$full_dir"
done

echo "✅ All experiments finished."
echo "📂 Results and plots live in: $RESULTS_ROOT"
