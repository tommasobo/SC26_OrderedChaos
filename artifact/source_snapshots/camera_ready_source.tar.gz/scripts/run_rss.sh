#!/bin/bash -eux

ALGO_FILE="/home/a-tobonato/M/msft-htsim/scripts/lb_algos.txt"
SIZES=(1024)

for SIZE in "${SIZES[@]}"; do
  printf "\n\n===== Running RSS experiments and plotting results: %s nodes =====\n\n" "$SIZE"

  # Subflow comparison (rss_*)
  : > "$ALGO_FILE"
  echo "rss_1,rss_2,rss_4,rss_8,rss_16,rss_32" > "$ALGO_FILE"
  python3 run_rss.py --topology_size "$SIZE" --jobs 4 --exp_name tornado --output_dir "rss_${SIZE}_subflow_tornado_2" --size_msg 2000000 --clean --load_algo_file "$ALGO_FILE"
  python3 plot_rss.py --results_dir "rss_${SIZE}_subflow_tornado_2" --output_dir "rss_${SIZE}" --output rss_subflow_tornado_2 --order_rss --show_ideal_tornado 2000000

  python3 run_rss.py --topology_size "$SIZE" --jobs 4 --exp_name tornado --output_dir "rss_${SIZE}_subflow_tornado_8" --size_msg 8000000 --clean --load_algo_file "$ALGO_FILE"
  python3 plot_rss.py --results_dir "rss_${SIZE}_subflow_tornado_8" --output_dir "rss_${SIZE}" --output rss_subflow_tornado_8 --order_rss --show_ideal_tornado 8000000

  # Baseline comparison (ecmp,rps,reps,rss)
  : > "$ALGO_FILE"
  echo "ecmp,reps,rps,rss" > "$ALGO_FILE"
  python3 run_rss.py --topology_size "$SIZE" --jobs 4 --exp_name tornado --output_dir "rss_${SIZE}_compare_tornado_2" --size_msg 2000000 --clean --load_algo_file "$ALGO_FILE"
  python3 plot_rss.py --results_dir "rss_${SIZE}_compare_tornado_2" --output_dir "rss_${SIZE}" --output rss_compare_tornado_2 --show_ideal_tornado 2000000

  python3 run_rss.py --topology_size "$SIZE" --jobs 4 --exp_name tornado --output_dir "rss_${SIZE}_compare_tornado_8" --size_msg 8000000 --clean --load_algo_file "$ALGO_FILE"
  python3 plot_rss.py --results_dir "rss_${SIZE}_compare_tornado_8" --output_dir "rss_${SIZE}" --output rss_compare_tornado_8 --show_ideal_tornado 8000000
done