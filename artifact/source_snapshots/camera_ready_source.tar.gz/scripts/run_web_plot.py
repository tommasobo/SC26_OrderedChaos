import os
import re
import argparse
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch

# new: parse completion time and total bytes
import re

def parse_flow_stats(file_path):
    pattern = re.compile(r'finished at ([0-9.]+).*total bytes (\d+)')
    stats = []
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            m = pattern.search(line)
            if m:
                stats.append((float(m.group(1)), int(m.group(2))))
    return stats

def parse_max_fct(file_path):
    """Scan the file for 'finished at X' and return all X values."""
    pattern = re.compile(r'finished at ([0-9.]+)')
    times = []
    # ignore invalid UTF-8 bytes when reading
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            m = pattern.search(line)
            if m:
                times.append(float(m.group(1)))
    return times

# add a rename map for visualization
RENAME_MAP = {
    "pfld2_no_trim": "PFLD (Probe every 16) -\nNo Trim",
    "pfld1_no_trim": "PFLD16 (Probe every 1) -\nNo Trim",
    "pfld0_no_trim": "PFLD16 (Probe every RTT) -\nNo Trim",
    "pfld3_no_trim": "PFLD16 (Probe only msg end) -\nNo Trim",
    "ecmp_no_trim": "ECMP - No Trim",
    "ecmp2_no_trim": "ECMP - No Trim - NACK PSN gap",
    "ecmp_trim": "ECMP - Yes Trim",
    "flowbender_no_trim": "FlowBender - No Trim",
    "flowbender2_no_trim": "FlowBender - No Trim - NACK PSN gap",
    "flowbender_trim": "FlowBender - Yes Trim",    
    "reps_no_trim": "REPS - No Trim",
    "reps_trim": "REPS - Yes Trim",    
    "rps_no_trim": "RPS - No Trim",
    "rps_trim": "RPS - Yes Trim",    
    "pfld1_trim": "RSS - Yes Trim",   
    "rss_no_trim": "RSS - No Trim",
    "rss2_no_trim": "RSS - No Trim - NACK PSN gap",
}

def main():
    p = argparse.ArgumentParser(
        description="Plot max flow completion time per LB+trim setting (violin)"
    )
    p.add_argument("--results_dir", help="Base directory containing one sub-folder per run")
    p.add_argument("-o", "--output", default="max_fct_violin.png", help="Filename for the saved violin plot")
    p.add_argument("--show", action="store_true", help="Show the plot interactively after saving")
    p.add_argument("--divide_plots", action="store_true", help="Generate separate plots by message size categories")
    p.add_argument("--custom", action="store_true", help="Only annotate min and mean; treat 99th percentile as max")
    args = p.parse_args()

    # prepare data containers
    labels = []
    all_values = []
    all_stats = []  # list of lists of (time, bytes)
    # our palette
    colors = ["#262636", "#7e2c40", "#a42f44", "#d85034", 
              "#ee8143", "#228a8d", "#145a5c", "#45448b", 
              "#7c7ae6", "#3885cf"]
    all_colors = []

    # each subfolder corresponds to one run
    for sub in sorted(os.listdir(args.results_dir)):
        # drop unsupported runs
        if sub in ("pfld2_trim", "pfld0_trim", "pfld3_trim", "rps_no_trim", "rps_trim"):
            continue
        # apply rename if needed
        label = RENAME_MAP.get(sub, sub)
        subdir = os.path.join(args.results_dir, sub)
        if not os.path.isdir(subdir):
            continue

        # pick color: first color if “no_trim” in sub else second
        color = colors[0] if "no_trim" in sub else colors[1]

        # gather all seed files
        seed_files = [fn for fn in os.listdir(subdir)
                      if fn.startswith("log_seed_") and fn.endswith(".out")]
        if not seed_files:
            print(f"⚠️  no log_seed_*.dat in {subdir}, skipping")
            continue

        # parse flow stats for each seed
        seed_stats = []
        for fn in seed_files:
            seed_stats.extend(parse_flow_stats(os.path.join(subdir, fn)))

        labels.append(label)
        all_colors.append(color)
        if args.divide_plots:
            all_stats.append(seed_stats)
        else:
            # extract times only
            all_values.append([t for t, _ in seed_stats])

    # rename for display
    labels = [RENAME_MAP.get(lbl, lbl) for lbl in labels]

    # sort data by label
    if args.divide_plots:
        items = list(zip(labels, all_stats, all_colors))
        items.sort(key=lambda x: x[0])
        labels, all_stats, all_colors = zip(*items)
        labels = list(labels)
        all_stats = list(all_stats)
        all_colors = list(all_colors)
    else:
        items = list(zip(labels, all_values, all_colors))
        items.sort(key=lambda x: x[0])
        labels, all_values, all_colors = zip(*items)
        labels = list(labels)
        all_values = list(all_values)
        all_colors = list(all_colors)

    # branch for divided plots
    if args.divide_plots:
        # output base and extension
        base, ext = os.path.splitext(args.output)
        # message size bins: (key, title, low_bytes, high_bytes)
        BINS = [
            ('small',  'Small Messages (0-100KiB)',      0,        100*1024),
            ('medium', 'Medium Messages (100KiB-1MiB)',    100*1024, 1024*1024),
            ('large',  'Large Messages (1MiB-10MiB)',      1024*1024,5*1024*1024),
            ('xlarge', 'Extra Large (>10MiB)',            5*1024*1024, float('inf'))
        ]
        # create a legend patches once
        patch_no = Patch(facecolor=colors[0], edgecolor='black', alpha=0.7, label='Without Trimming')
        patch_yes = Patch(facecolor=colors[1], edgecolor='black', alpha=0.7, label='With Trimming')
        for key, title, low, high in BINS:
            # filter per bin
            vals_bin = [[t for t, b in stats if low <= b < high] for stats in all_stats]
            # for custom, trim values above 99th percentile
            p99_bin = [np.percentile(vals,99) if vals else 0 for vals in vals_bin]
            if args.custom:
                plot_vals = [[v for v in vals if v <= p] for vals, p in zip(vals_bin, p99_bin)]
            else:
                plot_vals = vals_bin
            # compute actual plot data ranges for clipping
            min_plot_vals = [min(v) if v else 0 for v in plot_vals]
            max_plot_vals = [max(v) if v else 0 for v in plot_vals]
            plt.figure(figsize=(10,6))
            parts = plt.violinplot(plot_vals, showmeans=False, showmedians=True)
            # color violins
            for body, col in zip(parts['bodies'], all_colors):
                body.set_facecolor(col)
                body.set_edgecolor('black')
                body.set_alpha(0.7)
            # color lines
            for coll in ('cmins','cmaxes','cmedians','cbars'):
                lc = parts.get(coll)
                if lc is not None:
                    lc.set_color(all_colors)
                    lc.set_linewidth(1.0)
                    lc.set_zorder(5)
            # compute marker positions: use filtered max when custom, else raw 99th percentile
            if args.custom:
                p99 = max_plot_vals
            else:
                p99 = [np.percentile(vals,99) if vals else 0 for vals in vals_bin]
            # clamp violin bodies to actual data when custom
            if args.custom:
                for idx, body in enumerate(parts['bodies']):
                    path = body.get_paths()[0]
                    verts = path.vertices
                    verts[:,1] = np.clip(verts[:,1], min_plot_vals[idx], max_plot_vals[idx])
            xs = range(1, len(labels)+1)
            h99 = plt.scatter(xs, p99, color='black', marker='x', label='99th percentile', zorder=10)
            for xi, yi in zip(xs, p99):
                plt.text(xi + 0.2, yi, f"{yi:.0f}", ha='left', va='bottom', fontsize=10)
            # annotate min, mean, and max separately
            for idx, orig_vals in enumerate(vals_bin):
                filtered = plot_vals[idx]
                if not filtered:
                    continue
                mi, me, ma = min(filtered), np.mean(filtered), max(filtered)
                span = ma - mi
                offset = span * 0.03
                x = idx + 1
                # min at bottom
                plt.text(x, mi - offset, f"{mi:.0f}", ha='center', va='top', fontsize=10)
                # mean at mean line, offset right
                plt.text(x + 0.2, me, f"{me:.0f}", ha='left',   va='center', fontsize=10)
                # max at top (suppress if custom)
                if not args.custom:
                    plt.text(x, ma + offset, f"{ma:.0f}", ha='center', va='bottom', fontsize=10)
            # labels and legend
            plt.xticks(xs, labels, rotation=45, ha='right')
            plt.xlabel("Algorithm Considered")
            plt.ylabel("Flow Completion Time (us)")
            # include total message count in title
            total_count = len(plot_vals[0]) if plot_vals and plot_vals[0] else 0
            plt.title(f"FCT per LB+trim - {title} (Total Msg: {int(total_count*9.4)})")
            plt.legend(handles=[patch_no, patch_yes, h99], loc='upper right')
            plt.tight_layout()
            output_path = f"{base}_{key}{ext}"
            plt.savefig(output_path)
            print(f"Saved {title} violin plot to {output_path}")
            if args.show:
                plt.show()
        return

    # regular violin plot
    plt.figure(figsize=(10,6))
    parts = plt.violinplot(
        all_values,
        showmeans=False,
        showmedians=True,
        showextrema=not args.custom
    )

    # color each violin body
    for body, col in zip(parts['bodies'], all_colors):
        body.set_facecolor(col)
        body.set_edgecolor('black')
        body.set_alpha(0.7)

    # color the interior lines (min/max caps + median line)
    for coll_name in ('cmins', 'cmaxes', 'cmedians', 'cbars'):
        lc = parts.get(coll_name)
        if lc is not None:
            # assign each segment the matching violin color
            lc.set_color(all_colors)
            lc.set_linewidth(1.0)
            lc.set_zorder(5)

    plt.xticks(range(1, len(labels)+1), labels, rotation=45, ha='right')
    plt.xlabel("Algorithm Considered")
    plt.ylabel("Flow Completion Time (us)")
    plt.title("Max FCT per LoadBalancing Algo & Trimming Mode - 100 Runs (Min, Mean, Max) - No Random Drops")
    #plt.ylim(65,100)

    # compute and overlay 99th percentile
    # compute marker positions: use filtered max when custom, else raw 99th percentile
    if args.custom:
        p99 = [max(vals) for vals in all_values]
    else:
        p99 = [np.percentile(vals, 99) for vals in all_values]
    xs  = range(1, len(labels) + 1)
    # draw 99th-pct as black X’s on top
    h99 = plt.scatter(xs, p99,
                     color='black',
                     marker='x',
                     label='99th percentile',
                     zorder=10)
    # annotate 99th percentile values
    for xi, yi in zip(xs, p99):
        # offset text to the right of the marker
        plt.text(xi + 0.1, yi, f"{yi:.0f}", ha='left', va='bottom', fontsize=11)

    # add legend entries for trimming colors
    patch_no = Patch(facecolor=colors[0],
                     edgecolor='black',
                     alpha=0.7,
                     label='Without Trimming')
    patch_yes = Patch(facecolor=colors[1],
                      edgecolor='black',
                      alpha=0.7,
                      label='With Trimming')
    plt.legend(handles=[patch_no, patch_yes, h99],
               loc='upper right')

    # annotate min, mean and max (no decimals) on top of each violin
    global_min = min(min(v) for v in all_values)
    global_max = max(max(v) for v in all_values)
    y_offset = (global_max - global_min) * 0.03
    for idx, vals in enumerate(all_values):
        mi, me, ma = min(vals), np.mean(vals), max(vals)
        # prepare annotation text, omit max if custom
        if args.custom:
            txt = f"{mi:.0f},{me:.0f}"
        else:
            txt = f"{mi:.0f},{me:.0f},{ma:.0f}"
        plt.text(idx + 1, ma + y_offset, txt,
                 ha='center', va='bottom', fontsize=8.7)

    plt.tight_layout()
    plt.savefig(args.output)
    print(f"Saved violin plot to {args.output}")
    if args.show:
        plt.show()

if __name__ == "__main__":
    main()