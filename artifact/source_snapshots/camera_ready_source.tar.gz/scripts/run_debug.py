import os
import subprocess
import concurrent.futures
import argparse
import shutil


lb_algos = ["pfld0", "pfld1", "pfld2", "pfld3", "apfld4_1", "apfld5_2", "ecmp", "rps", "flowbender", "reps"]


lb_algos = ["pfld0", "pfld1", "pfld2", "pfld3"]

trimming = [False, True]


def getLBCmdLine(input_name):
    if input_name == "rps":
        return "oblivious"
    if input_name.startswith("rss"):
        return "rss"
    if input_name.startswith("ecmp2"):
        return "ecmp"
    if input_name.startswith("rss2"):
        return "rss"
    if input_name.startswith("flowbender2"):
        return "flowbender"
    return input_name

def getTrimmingFlag(trim):
    # in htsim: -disable_trim turns trimming OFF
    return "" if trim else "-disable_trim"

def skipCombination(algo,trim):
    # Skip combinations that are not supported
    if algo.startswith("rss") and trim:
        return True
    if algo.startswith("rss2") and trim:
        return True
    if algo.startswith("ecmp2") and trim:
        return True
    if algo.startswith("flowbender2") and trim:
        return True
    return False


def make_cmd(algo, trim, base_out_dir, seed, exp_name, corr_rate, drop_psn):

    if skipCombination(algo, trim):
        return None

    # pick actual lb string
    lb = getLBCmdLine(algo)
    if algo.startswith("pfld"):
        lb = "rss"
    elif algo.startswith("apfld"):
        lb = "rss"

    probe_every = 1
    if algo == "pfld1":
        probe_every = 1
    elif algo == "pfld2":
        probe_every = 16
    elif algo == "pfld0":
        probe_every = 0
    elif algo == "pfld3":
        probe_every = -1

    trim_flag = getTrimmingFlag(trim)

    # no more seed subfolder—just algo_trim
    out_dir = os.path.join(
        base_out_dir,
        f"{algo}_{'trim' if trim else 'no_trim'}"
    )
    os.makedirs(out_dir, exist_ok=True)

    cmd = [
        "/home/a-tobonato/M/msft-htsim/build/htsim_uec",
        "-data_collection_config",
        "/home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json",
        "-end", "10000",
        "-seed", str(seed),
        "-tm", "/home/a-tobonato/M/msft-htsim/scripts/connection_matrices/{exp_name}".format(exp_name=exp_name),
        "-topo", "/home/a-tobonato/M/msft-htsim/scripts/topologies/topo=fat_tree:over_sub=2:nodes=128:link_speed_gbps=400.topo",
        "-q", "151",
        "-cwnd", "151",
        "-mtu", "4160",
        "-sack_threshold", "0",
        "-ecn", "38", "113",
        "-switch_random_drop_prob", str(corr_rate),
        "-fail_psn", str(drop_psn),
        "-load_balancing_algo", lb,
    ]

    # PFLD‐only flags
    if algo.startswith("pfld") and not trim:
        cmd += [
            "-precisefastlossrecovery", "3",
            "-pflr_proactive_probe", str(probe_every),
            "-pflr_proactive_rtx_probe",
            "-no_droping_low_header",
        ]
    elif algo == "ecmp" and not trim:
        cmd += [
        ]
    elif algo == "ecmp2" and not trim:
        cmd += [
            "-precisefastlossrecovery", "1",
            "-no_droping_low_header",
        ]
    elif algo == "rss2" and not trim:
        cmd += [
            "-precisefastlossrecovery", "3",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(-1),
        ]
    elif algo.startswith("apfld4_1") and not trim:
        cmd += [
            "-precisefastlossrecovery", "0",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(0),
        ]
    elif algo.startswith("apfld5_2") and not trim:
        cmd += [
            "-precisefastlossrecovery", "1",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(0),
        ]
    elif algo.startswith("apfld6_3") and not trim:
        cmd += [
            "-precisefastlossrecovery", "2",
            "-no_droping_low_header",
            "-pflr_proactive_probe", str(0),
        ]
    elif algo == "flowbender" and not trim:
        cmd += [
        ]
    elif algo == "flowbender2" and not trim:
        cmd += [
            "-precisefastlossrecovery", "1",
            "-no_droping_low_header",
        ]
    elif algo.startswith("pfld") and trim:
        cmd += ["-no_droping_low_header"]

    cmd += [
        "-linkspeed", "400000",
        "-rss_parameters", "mean_rtt", "16", "0.1", "0", "0", "25",
        "-sender_cc_only",
        "-sender_cc_algo", "dctcp",
        trim_flag,
        "-data_collection_dir", out_dir,
        # include seed in the log filename
        "-o", f"{out_dir}/log_seed_{seed}.dat",
    ]
    return [p for p in cmd if p]


def run(cmd):
    # simulator data file (via '-o') - leave it for the sim to write
    data_file = cmd[-1]
    out_dir = os.path.dirname(data_file)
    algo, trimflag = os.path.basename(out_dir).split('_', 1)

    # create a separate .out log
    log_file = os.path.splitext(data_file)[0] + ".out"

    # header for the log
    header = (
        f"# Configuration\n"
        f"load_balancing = {algo}\n"
        f"trimming      = {'ON' if trimflag=='trim' else 'OFF'}\n\n"
    )

    print("Running:", " ".join(cmd), ">", log_file)

    # write header and capture stdout/stderr into .out
    with open(log_file, "w") as f_log:
        f_log.write(header)
        p = subprocess.Popen(cmd, stdout=f_log, stderr=subprocess.STDOUT, text=True)
        ret = p.wait()

    if ret != 0:
        print(f"→ FAILED (code={ret}) in {out_dir}")
        print("Command:", " ".join(cmd))

    return ret


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run htsim experiments in parallel for various LB algos and trimming."
    )
    parser.add_argument(
        "--output_dir", "-o",
        required=True,
        help="Base directory where per‐run output folders will be created."
    )
    parser.add_argument(
        "--exp_name", "-e",
        required=True,
        help="Name of the experiment (.cm file)."
    )
    parser.add_argument(
        "--jobs", "-j",
        type=int,
        default=None,
        help="Number of parallel processes (defaults to number of CPUs)"
    )
    parser.add_argument(
        "--runs", "-n",
        type=int,
        default=1,
        help="How many times to rerun each config (with different seeds)"
    )
    parser.add_argument(
        "--corruption_rate", "-c",
        type=float,
        default=0.0,
        help="Packet corruption rate (0.0 - 1.0)"
    )
    parser.add_argument(
        "--drop_psn", "-p",
        type=int,
        default=-1,
        help="Packet PSN to drop"
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="Clean the output directory before running experiments"
    )
    args = parser.parse_args()

    # clean the output directory if requested
    if args.clean and os.path.exists(args.output_dir):
        print(f"Cleaning existing output directory {args.output_dir}")
        shutil.rmtree(args.output_dir)
    # ensure output directory exists
    os.makedirs(args.output_dir, exist_ok=True)

    max_workers = args.jobs or os.cpu_count()

    seeds = range(1, args.runs + 1)
    cmds = [
        make_cmd(algo, trim, args.output_dir, seed, args.exp_name, args.corruption_rate, args.drop_psn)
        for algo in lb_algos
        for trim in trimming
        for seed in seeds
    ]

    # Filter out None commands (unsupported combinations)
    cmds = [cmd for cmd in cmds if cmd is not None]

    with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as pool:
        for ret in pool.map(run, cmds):
            if ret != 0:
                print("Aborting remaining jobs due to failure.")
                pool.shutdown(cancel_futures=True)
                break