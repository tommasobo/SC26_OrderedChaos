#!/bin/bash -eux

ALGO_FILE="/home/a-tobonato/M/msft-htsim/scripts/lb_algos.txt"
SIZES=(128)
FAILING_LINK=1

for SIZE in "${SIZES[@]}"; do
  printf "\n\n===== Running RSS experiments and plotting results: %s nodes =====\n\n" "$SIZE"

  if (( SIZE == 1024 )); then
    FAILING_LINK=60
  else
    FAILING_LINK=6
  fi

  # Baseline comparison (ecmp,rps,reps,rss)
  : > "$ALGO_FILE"
  echo "rps,rss" > "$ALGO_FILE"
  python3 run_rss.py --topology_size "$SIZE" --jobs 4 --interval 1000 --exp_name tornado --output_dir "rss_fail_${SIZE}_compare_tornado_2" --size_msg 2000000 --clean --full_fail --to_fail "$FAILING_LINK" --load_algo_file "$ALGO_FILE"
  python3 plot_rss.py --results_dir "rss_fail_${SIZE}_compare_tornado_2" --output_dir "rss_fail_${SIZE}" --output rss_compare_tornado_2

  python3 run_rss.py --topology_size "$SIZE" --jobs 4 --interval 1000 --exp_name tornado --output_dir "rss_fail_${SIZE}_compare_tornado_8" --size_msg 8000000 --clean --full_fail --to_fail "$FAILING_LINK" --load_algo_file "$ALGO_FILE"
  python3 plot_rss.py --results_dir "rss_fail_${SIZE}_compare_tornado_8" --output_dir "rss_fail_${SIZE}" --output rss_compare_tornado_8
done