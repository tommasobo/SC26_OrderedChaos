#!/usr/bin/env python3
import os
import re
import argparse
import numpy as np
import matplotlib


def select_backend(want_show: bool):
    """Configure Matplotlib backend. Use interactive if --show requested and available; else Agg."""
    if want_show:
        for cand in ("QtAgg", "Qt5Agg", "TkAgg"):
            try:
                matplotlib.use(cand, force=True)
                return
            except Exception:
                continue
    matplotlib.use("Agg", force=True)


# parse one log for (time, bytes)
FLOW_RE = re.compile(r"finished at ([0-9]*\.?[0-9]+).*total bytes (\d+)")


def parse_flow_file(path):
    tbl = []
    try:
        with open(path) as f:
            for L in f:
                m = FLOW_RE.search(L)
                if m:
                    tbl.append((float(m.group(1)), int(m.group(2))))
    except Exception:
        pass
    return tbl


# load all flows from each directory (dir basename → list of (time,bytes))
ALLOWED_EXTS = (".dat", ".log", ".out")


def load_data(dirs):
    out = {}
    for d in dirs:
        alg = os.path.basename(d.rstrip("/")) or d
        flows = []
        if os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.endswith(ALLOWED_EXTS):
                    flows += parse_flow_file(os.path.join(d, fn))
        out[alg] = flows
    return out


# one violin per algorithm (filter out empty)


def plot_all(plt, data, outpath):
    labels, groups = [], []
    for alg in sorted(data.keys()):
        times = [t for t, _ in data[alg]]
        if times:
            labels.append(alg)
            groups.append(times)
    if not groups:
        raise RuntimeError("no flow data to plot (no .dat/.log/.out files or no 'finished at' lines)")
    plt.figure(figsize=(8, 6))
    plt.violinplot(groups, showmeans=True)
    plt.xticks(range(1, len(labels) + 1), labels, rotation=30)
    plt.ylabel("Flow completion time")
    plt.title("Flows per Algorithm")
    plt.tight_layout()
    plt.savefig(outpath, dpi=300)


# violins per algorithm×byte bin (filter out empty)


def plot_bins(plt, data, bins, outpath, filter_percentile: float | None = None):
    labels, groups = [], []
    for alg in sorted(data.keys()):
        for i in range(len(bins) - 1):
            lo, hi = bins[i], bins[i + 1]
            sel = [t for t, b in data[alg] if lo <= b < hi]
            if not sel:
                continue
            if filter_percentile is not None and len(sel) > 0:
                try:
                    cutoff = float(np.percentile(sel, filter_percentile))
                    sel = [t for t in sel if t <= cutoff]
                except Exception:
                    pass
            if sel:
                label = f"{alg} {lo}-{hi}"
                if filter_percentile is not None:
                    label += f" ≤p{int(filter_percentile)}"
                labels.append(label)
                groups.append(sel)
    if not groups:
        raise RuntimeError("no flow data in any requested bins to plot")
    plt.figure(figsize=(10, 6))
    plt.violinplot(groups, showmeans=True)
    plt.xticks(range(1, len(labels) + 1), labels, rotation=45, ha="right")
    plt.ylabel("Flow completion time")
    plt.title("Flows by Size Bins")
    plt.tight_layout()
    plt.savefig(outpath, dpi=300)


def main():
    p = argparse.ArgumentParser(description="Plot flow completion violins")
    p.add_argument(
        "--method",
        choices=["all", "bins"],
        default="all",
        help="`all`: one violin per algo; `bins`: split by bytes",
    )
    p.add_argument(
        "--input_dirs",
        nargs="+",
        required=True,
        help="dirs named by algorithm, each with .dat/.log/.out logs",
    )
    p.add_argument(
        "--bins",
        nargs="+",
        type=int,
        default=[0, 100000, 500000, 1000000],
        help="byte boundaries for `bins` mode",
    )
    p.add_argument(
        "--filter_percentile",
        type=float,
        default=None,
        help="When method=bins, drop runtimes above this percentile within each bin (e.g., 99).",
    )
    p.add_argument(
        "--output",
        default="flow_completion_times_violin.png",
        help="output plot file",
    )
    p.add_argument(
        "--show",
        action="store_true",
        help="Display the plot window after saving (requires GUI backend)",
    )
    args = p.parse_args()

    select_backend(args.show)
    import matplotlib.pyplot as plt  # import after backend selection

    data = load_data(args.input_dirs)
    if args.method == "all":
        plot_all(plt, data, args.output)
    else:
        plot_bins(plt, data, args.bins, args.output, args.filter_percentile)

    if args.show:
        plt.show()


if __name__ == "__main__":
    main()
