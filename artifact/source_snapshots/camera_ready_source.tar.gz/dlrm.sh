#!/usr/bin/env bash

mkdir -p all/ai

/home/a-tobonato/M/msft-htsim/build/htsim_uec \
  -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json \
  -end 10000 \
  -seed 1 \
  -goal /home/a-tobonato/M/msft-htsim/sim/lgs/dlrm_N4_GPU4_300GB.bin \
  -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/16_400.topo \
  -q 151 \
  -cwnd 151 \
  -mtu 4160 \
  -sack_threshold 0 \
  -ecn 38 113 \
  -switch_random_drop_prob 0.001 \
  -fail_psn -1 \
  -load_balancing_algo rss \
  -linkspeed 400000 \
  -rss_parameters mean_rtt 16 0.1 0 0 25 \
  -sender_cc_only \
  -sender_cc_algo dctcp \
  -disable_trim \
  -data_collection_dir all/ai \
  -o all/ai/log_seed_1.dat \
  -nodes 128 \
  -rto_ratio 2 \
  -lgs_percent 100 > all/ai/dlrm_400_no.tmp


/home/a-tobonato/M/msft-htsim/build/htsim_uec \
  -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json \
  -end 10000 \
  -seed 1 \
  -goal /home/a-tobonato/M/msft-htsim/sim/lgs/dlrm_N4_GPU4_300GB.bin \
  -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/16_400.topo \
  -q 151 \
  -cwnd 151 \
  -mtu 4160 \
  -sack_threshold 0 \
  -ecn 38 113 \
  -switch_random_drop_prob 0.001 \
  -fail_psn -1 \
  -load_balancing_algo rss \
  -precisefastlossrecovery 3 \
  -pflr_proactive_probe 0 \
  -pflr_proactive_rtx_probe \
  -no_droping_low_header \
  -linkspeed 400000 \
  -rss_parameters mean_rtt 16 0.1 0 0 25 \
  -sender_cc_only \
  -sender_cc_algo dctcp \
  -disable_trim \
  -data_collection_dir all/ai \
  -o all/ai/log_seed_1.dat \
  -nodes 128 \
  -rto_ratio 2 \
  -lgs_percent 100 > all/ai/dlrm_400_yes.tmp



/home/a-tobonato/M/msft-htsim/build/htsim_uec \
  -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json \
  -end 10000 \
  -seed 1 \
  -goal /home/a-tobonato/M/msft-htsim/sim/lgs/dlrm_N4_GPU4_300GB.bin \
  -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/16_800.topo \
  -q 151 \
  -cwnd 151 \
  -mtu 4160 \
  -sack_threshold 0 \
  -ecn 38 113 \
  -switch_random_drop_prob 0.001 \
  -fail_psn -1 \
  -load_balancing_algo rss \
  -linkspeed 800000 \
  -rss_parameters mean_rtt 16 0.1 0 0 25 \
  -sender_cc_only \
  -sender_cc_algo dctcp \
  -disable_trim \
  -data_collection_dir all/ai \
  -o all/ai/log_seed_1.dat \
  -nodes 128 \
  -rto_ratio 2 \
  -lgs_percent 100 > all/ai/dlrm_800_no.tmp


/home/a-tobonato/M/msft-htsim/build/htsim_uec \
  -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json \
  -end 10000 \
  -seed 1 \
  -goal /home/a-tobonato/M/msft-htsim/sim/lgs/dlrm_N4_GPU4_300GB.bin \
  -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/16_800.topo \
  -q 151 \
  -cwnd 151 \
  -mtu 4160 \
  -sack_threshold 0 \
  -ecn 38 113 \
  -switch_random_drop_prob 0.001 \
  -fail_psn -1 \
  -load_balancing_algo rss \
  -precisefastlossrecovery 3 \
  -pflr_proactive_probe 0 \
  -pflr_proactive_rtx_probe \
  -no_droping_low_header \
  -linkspeed 800000 \
  -rss_parameters mean_rtt 16 0.1 0 0 25 \
  -sender_cc_only \
  -sender_cc_algo dctcp \
  -disable_trim \
  -data_collection_dir all/ai \
  -o all/ai/log_seed_1.dat \
  -nodes 128 \
  -rto_ratio 2 \
  -lgs_percent 100 > all/ai/dlrm_800_yes.tmp
