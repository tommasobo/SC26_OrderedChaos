#!/usr/bin/env bash

#python3 /home/tbonato/msft-htsim/compare.py --linkspeed 200000 --delay 2000 --topo_size 16 --goal llama.bin --lgs_percentage 12 --workers 8 --out_dir run_200
python3 /home/tbonato/msft-htsim/compare.py --linkspeed 400000 --delay 1500 --topo_size 64 --goal moe.bin --lgs_percentage 3 --workers 8 --out_dir run_400_moe --verbose
#python3 /home/tbonato/msft-htsim/compare.py --linkspeed 800000 --delay 2000 --topo_size 16 --goal llama.bin --lgs_percentage 12 --workers 8 --out_dir run_800