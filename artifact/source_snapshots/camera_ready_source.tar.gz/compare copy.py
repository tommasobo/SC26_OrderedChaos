#!/usr/bin/env python3
import argparse
import subprocess
import sys
import shutil
import signal
from pathlib import Path
from dataclasses import dataclass, field
from typing import List
import concurrent.futures

# Color + logging helpers
COLOR_RESET = "\033[0m"
COLOR_GREEN = "\033[32m"
COLOR_RED = "\033[31m"
COLOR_CYAN = "\033[36m"
COLOR_YELLOW = "\033[33m"
COLOR_BOLD = "\033[1m"
VERBOSE = False
EXTRA_VERBOSE = False

def _log(msg, color=COLOR_CYAN, force=False, stream=sys.stdout):
    if not VERBOSE and not force:
        return
    print(f"{color}{msg}{COLOR_RESET}", file=stream)

MTU_SIZE = 4160  # MTU size in bytes
ACK_SIZE = 64  # ACK packet size in bytes
ECN_MIN_PERCENTAGE = 0.2  # Minimum ECN marking percentage
ECN_MAX_PERCENTAGE = 0.8  # Maximum ECN marking percentage
CONFIG = ["rss", "reps", "ecmp"]
EXTRA_CONFIG = ["rss1", "rss2"]
DROP_CONFIG = [0.001, 0.0001, 0.00001]


def addExtra(name):
    if name == "rss1":
        return [
            "-precisefastlossrecovery", "3",
            "-pflr_proactive_probe", "0",
            "-pflr_proactive_rtx_probe",
            "-no_droping_low_header",
        ]
    if name == "rss2":
        return [
            "-precisefastlossrecovery", "3",
            "-pflr_proactive_probe", "16",
            "-pflr_proactive_rtx_probe",
            "-no_droping_low_header",
        ]
    return []

def getBDP(linkspeed, delay):
    # linkspeed in Mbps, delay in nanoseconds
    linkspeed_gbps = linkspeed / 1000  # Convert Mbps to Gbps
    total_delay = 4 * 2 * delay  # hops, round-trip time, delay value
    total_transmission_time = (MTU_SIZE*8/linkspeed_gbps*4)+(ACK_SIZE*8/linkspeed_gbps*4)
    total_delay += total_transmission_time
    bdp_bytes = linkspeed_gbps * total_delay / 8  # Convert Mbps to bytes per second
    return int(bdp_bytes)

def getTopo(size, linkspeed):
    if size == 64:
        return "/home/tbonato/msft-htsim/scripts/topologies/64_{}.topo".format(int(linkspeed/1000)) 
    elif size == 128:
        return "/home/tbonato/msft-htsim/scripts/topologies/128_{}.topo".format(int(linkspeed/1000))
    elif size == 16:
        return "/home/tbonato/msft-htsim/scripts/topologies/16_{}.topo".format(int(linkspeed/1000))
    else:
        raise ValueError(f"Unsupported topology size: {size}")

def build_command(arguments, algo, metrics_file, drop_prob, extra_args=None):
    # (renamed output_file -> metrics_file; rest unchanged except assignment to -o)
    bdp = getBDP(arguments.linkspeed, arguments.delay)
    bdp_packets = int(bdp / MTU_SIZE)
    topology_path = getTopo(arguments.topo_size, arguments.linkspeed)
    command = [
        "/home/tbonato/msft-htsim/build/htsim_uec",
        "-data_collection_config", "/home/tbonato/msft-htsim/scripts/metrics_collection_policies/collect_default.json",
        "-end", "10000", "-seed", "1",
        "-goal", f"/home/tbonato/msft-htsim/sim/lgs/{arguments.goal}",
        "-topo", topology_path,
        "-q", str(bdp_packets), "-cwnd", str(bdp_packets), "-mtu", "4160",
        "-sack_threshold", "0",
        "-ecn", str(int(bdp_packets*ECN_MIN_PERCENTAGE)), str(int(bdp_packets*ECN_MAX_PERCENTAGE)),
        "-switch_random_drop_prob", str(drop_prob),
        "-fail_psn", "-1",
        "-rto_ratio", "2",
        "-load_balancing_algo", algo,
        "-linkspeed", str(arguments.linkspeed),
        "-rss_parameters", "mean_rtt", "16", "50", "0", "0", "25",
        "-sender_cc_only", "-sender_cc_algo", "dctcp",
        "-disable_trim",
        "-data_collection_dir", str(arguments.out_dir),
        "-o", str(metrics_file),          # now points to separate metrics file
        "-nodes", str(arguments.topo_size),
        "-lgs_percent", str(arguments.lgs_percentage),
    ]
    command += getAlgoSpecificArgs(algo)
    if extra_args:
        command += extra_args
    return command

def getAlgoSpecificArgs(algo):
    if algo == "rss":
        return []  # Already included in base command
    elif algo == "reps":
        return []
    elif algo == "ecmp":
        return []
    else:
        raise ValueError(f"Unknown algorithm: {algo}")

def run_algo(algo, drop_prob, args, log_file, extra_args=None):
    metrics_file = log_file.with_suffix(".bin")
    cmd = build_command(args, algo, metrics_file, drop_prob, extra_args)
    tag = f"{algo} drop={drop_prob}" + (" extra" if extra_args else "")
    if EXTRA_VERBOSE:
        # Print the full command line being executed.
        print(f"{COLOR_YELLOW}CMD   {tag}: {' '.join(cmd)}{COLOR_RESET}")
    _log(f"START {tag}", COLOR_CYAN)
    with open(log_file, "w") as lf:
        proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT)
        rc = proc.wait()
    if rc != 0:
        _log(f"FAIL  {tag} (rc={rc})", COLOR_RED, force=True, stream=sys.stderr)
        raise RuntimeError(f"{tag} exited with code {rc}")
    _log(f"DONE  {tag}", COLOR_GREEN)
    return rc

def main():
    ap = argparse.ArgumentParser(
        description="Run htsim_uec for all algorithms x drop probabilities (baseline + variants)."
    )
    ap.add_argument("--file_name", default="study",
                    help="(Legacy/unused) Base name placeholder kept for compatibility.")
    ap.add_argument("--lgs_percentage", type=int, default=10,
                    help="Percentage of large flows (LGS) in the workload (integer).")
    ap.add_argument("--linkspeed", type=int, default=100000,
                    help="Link speed in Mbps (e.g. 100000 = 100 Gbps).")
    ap.add_argument("--delay", type=int, default=100000,
                    help="One-way propagation delay per hop in nanoseconds.")
    ap.add_argument("--topo_size", type=int, default=64, choices=[64, 128, 16, 1024],
                    help="Topology size (number of hosts).")
    ap.add_argument("--workers", type=int, default=4,
                    help="Maximum number of simulations to run concurrently.")
    ap.add_argument("--goal", default="tornado_128.goal",
                    help="Goal file name located under scripts/goals/.")
    ap.add_argument("--out_dir", default="logs",
                    help="Directory where per-algorithm log files will be written (created if absent).")
    ap.add_argument("--verbose", action="store_true",
                    help="Enable detailed per-run logging.")
    ap.add_argument("--extra-verbose", action="store_true",
                    help="Also print the full simulation command lines.")
    args = ap.parse_args()

    global VERBOSE, EXTRA_VERBOSE
    VERBOSE = args.verbose
    EXTRA_VERBOSE = args.extra_verbose

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    results = {}

    # Baseline (nodrop) runs
    _log("Running baseline (no-drop) variants...", COLOR_BOLD if VERBOSE else COLOR_CYAN, force=VERBOSE)
    baseline_futures = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        for algo in CONFIG:
            baseline_file = out_dir / f"{algo}_nodrop.txt"
            fut = executor.submit(run_algo, algo, 0.0, args, baseline_file)
            baseline_futures[fut] = (algo, "baseline", baseline_file)
        for fut, (algo, tag, _) in baseline_futures.items():
            try:
                fut.result()
                results[(algo, tag)] = "ok"
            except Exception as e:
                results[(algo, tag)] = f"failed: {e}"

    # Drop probability runs
    _log("Running drop probability matrix...", COLOR_BOLD if VERBOSE else COLOR_CYAN, force=VERBOSE)
    drop_tasks = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        for dp in DROP_CONFIG:
            dp_dir = out_dir / f"drop_{dp}"
            dp_dir.mkdir(parents=True, exist_ok=True)
            for algo in CONFIG:
                baseline_src = out_dir / f"{algo}_nodrop.txt"
                baseline_dst = dp_dir / f"{algo}_nodrop.txt"
                if baseline_src.exists():
                    baseline_dst.write_bytes(baseline_src.read_bytes())
                drop_file = dp_dir / f"{algo}_drop.txt"
                fut = executor.submit(run_algo, algo, dp, args, drop_file)
                drop_tasks.append((fut, algo, dp))
            for variant in EXTRA_CONFIG:
                extra_args = addExtra(variant)
                extra_file = dp_dir / f"{variant}_drop.txt"
                fut = executor.submit(run_algo, "rss", dp, args, extra_file, extra_args)
                drop_tasks.append((fut, variant, dp))
        for fut, algo, dp in drop_tasks:
            try:
                fut.result()
                results[(algo, dp)] = "ok"
            except Exception as e:
                results[(algo, dp)] = f"failed: {e}"

    # Summary (always printed)
    print(f"{COLOR_BOLD}Summary:{COLOR_RESET}")
    for (algo, key), status in results.items():
        ok = status == "ok"
        color = COLOR_GREEN if ok else COLOR_RED
        label = "baseline" if key == "baseline" else f"drop={key}"
        print(f"{color}{algo:<6} {label:<12} {status}{COLOR_RESET}")

if __name__ == "__main__":
    main()
