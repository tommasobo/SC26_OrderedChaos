#!/usr/bin/env bash

OUT_DIR="${1:-all/pfld0_no_trim}"
PRINT_DIR="${1:-study_drops}"
DROP_PROB="${2:-0.001}"
LOG_FILE="log_seed_1.dat"

mkdir -p "$OUT_DIR"
mkdir -p "$PRINT_DIR"

# Print and run first command
FIRST_CMD=(/home/a-tobonato/M/msft-htsim/build/htsim_uec
  -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json
  -end 10000
  -seed 1
  -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin
  -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo
  -q 151
  -cwnd 151
  -mtu 4160
  -sack_threshold 0
  -ecn 38 113
  -switch_random_drop_prob "$DROP_PROB"
  -fail_psn -1
  -load_balancing_algo rss
  -linkspeed 400000
  -rss_parameters mean_rtt 16 0.1 0 0 25
  -sender_cc_only
  -sender_cc_algo dctcp
  -disable_trim
  -data_collection_dir "$OUT_DIR"
  -o "$OUT_DIR/$LOG_FILE"
  -nodes 128
  -lgs_percent 30)
echo "First run command:"
echo "${FIRST_CMD[@]} > $PRINT_DIR/30rss.tmp"
"${FIRST_CMD[@]}" > "$PRINT_DIR"/30rss.tmp
/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo reps -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 30  > "$PRINT_DIR"/30reps.tmp
/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo ecmp -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 30  > "$PRINT_DIR"/30ecmp.tmp

echo "Finished 30% LGS runs"

/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo rss -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 60  > "$PRINT_DIR"/60rss.tmp
/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo reps -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 60  > "$PRINT_DIR"/60reps.tmp
/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo ecmp -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 60  > "$PRINT_DIR"/60ecmp.tmp

echo "Finished 60% LGS runs"

/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo rss -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 90  > "$PRINT_DIR"/90rss.tmp
/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo reps -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 90  > "$PRINT_DIR"/90reps.tmp
/home/a-tobonato/M/msft-htsim/build/htsim_uec -data_collection_config /home/a-tobonato/M/msft-htsim/scripts/metrics_collection_policies/collect_default.json -end 10000 -seed 1 -goal /home/a-tobonato/M/msft-htsim/sim/lgs/llama_N4_GPU16.bin -topo /home/a-tobonato/M/msft-htsim/scripts/topologies/64_400.topo -q 151 -cwnd 151 -mtu 4160 -sack_threshold 0 -ecn 38 113 -switch_random_drop_prob "$DROP_PROB" -fail_psn -1 -load_balancing_algo ecmp -linkspeed 400000 -rss_parameters mean_rtt 16 0.1 0 0 25 -sender_cc_only -sender_cc_algo dctcp -disable_trim -data_collection_dir "$OUT_DIR" -o "$OUT_DIR/$LOG_FILE" -nodes 128 -lgs_percent 90  > "$PRINT_DIR"/90ecmp.tmp