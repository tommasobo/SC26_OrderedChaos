import argparse

def main():
    parser = argparse.ArgumentParser(
        description="Generate a .cm connection file: header + src->dst entries."
    )
    parser.add_argument('--nodes', type=int, default=128,
                        help="Total nodes (0..nodes-1), default=128")
    parser.add_argument('--src',   type=int, default=0,
                        help="Source node ID, default=0")
    parser.add_argument('--dst',   type=int, default=100,
                        help="Destination node ID, default=100")
    parser.add_argument('--size',  type=int, required=True,
                        help="Bytes per send")
    parser.add_argument('--count', type=int, required=True,
                        help="Number of sends / connections")
    parser.add_argument('--interval', type=int, default=1000,
                        help="Time units between successive sends, default=1000")
    parser.add_argument('--output', '-o', type=str, default=None,
                        help="Optional output .cm path")
    args = parser.parse_args()

    # assemble lines in .cm format
    lines = []
    lines.append(f"Nodes {args.nodes}")
    lines.append(f"Connections {args.count}")
    for i in range(args.count):
        start = i * args.interval
        lines.append(f"{args.src}->{args.dst} id {i+1} start {start} size {args.size}")

    # output to file or stdout
    if args.output:
        with open(args.output, 'w') as f:
            f.write('\n'.join(lines))
    else:
        print('\n'.join(lines))

if __name__ == "__main__":
    main()
