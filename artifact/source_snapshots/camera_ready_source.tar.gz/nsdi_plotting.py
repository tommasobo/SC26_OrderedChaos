#!/usr/bin/env python3
"""
nsdi_plotting.py

Reads an experiment root folder that contains subfolders for different drop rates (e.g., drop_0, drop_0.0005).
Each drop-rate subfolder contains text files named after an algorithm plus optional seed and trim status:
  <algo>_trim_on.txt
  <algo>_trim_off.txt
  <algo>_seed1_trim_on.txt
  <algo>_seed2_trim_off.txt
Log lines contain substrings like:
  Flow Uec_28_92 flowId 29 uecSrc 28 finished at 94.5171 total packets 977 ...
We extract the numeric value after 'finished at'.

Dataframe columns: algorithm, trim_status (on/off), seed, drop_category (0 or >0), completion_time.

Plot: two stacked subplots (top: drop=0, bottom: drop>0). Within each subplot violins per algorithm with hue=trim_status.
If multiple seeds are detected (more than one distinct seed), all seeds' completion times are aggregated in the same violins (combined distribution).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import List, Dict, Tuple

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

FINISHED_AT_RE = re.compile(r"finished at ([0-9]*\.?[0-9]+)")
FLOAT_RE = re.compile(r"([0-9]*\.?[0-9]+)")
# Supports: algo_trim_on/off  AND  algo_seed3_trim_on/off
FILENAME_RE = re.compile(r"^(?P<algo>.+?)(?:_seed(?P<seed>\d+))?_(?P<trim>trim_on|trim_off)$")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Create violin plots over drop categories (0 vs >0) and trim status; auto-detect multi-seed.")
    p.add_argument("experiment_root", type=Path, help="Path to root experiment folder containing drop-rate subfolders")
    p.add_argument("--output", "-o", type=str, default="completion_times_violin.png", help="Output plot filename (saved inside root)")
    p.add_argument("--csv", type=str, default=None, help="Optional CSV filename to dump parsed data (inside root)")
    p.add_argument("--min-flows", type=int, default=1, help="Minimum number of flows required to include an algorithm/category")
    p.add_argument("--style", type=str, default="whitegrid", help="Seaborn style")
    p.add_argument("--palette", type=str, default="Set2", help="Seaborn palette")
    return p.parse_args()


def infer_drop_rate(subfolder: Path) -> float:
    m = FLOAT_RE.search(subfolder.name)
    if not m:
        return 0.0
    try:
        return float(m.group(1))
    except ValueError:
        return 0.0


def drop_category(rate: float) -> str:
    return '0' if rate == 0 else '>0'


def extract_completion_times(file_path: Path) -> List[float]:
    times: List[float] = []
    try:
        with file_path.open('r', errors='ignore') as f:
            for line in f:
                if 'finished at' not in line:
                    continue
                m = FINISHED_AT_RE.search(line)
                if m:
                    try:
                        times.append(float(m.group(1)))
                    except ValueError:
                        pass
    except FileNotFoundError:
        pass
    return times


def parse_filename(stem: str) -> Tuple[str, str, int]:
    m = FILENAME_RE.match(stem)
    if m:
        algo = m.group('algo')
        trim = 'on' if m.group('trim') == 'trim_on' else 'off'
        seed_str = m.group('seed')
        seed = int(seed_str) if seed_str else 1
    else:
        # Fallback to legacy naming without trim/seed tagging
        algo = stem
        trim = 'unknown'
        seed = 1
    return algo, trim, seed


def collect_data(root: Path, min_flows: int) -> pd.DataFrame:
    records: List[Dict] = []
    if not root.is_dir():
        raise FileNotFoundError(f"Experiment root {root} not found or not a directory")

    for sub in sorted(root.iterdir()):
        if not sub.is_dir():
            continue
        rate = infer_drop_rate(sub)
        cat = drop_category(rate)
        for txt in sorted(sub.glob('*.txt')):
            algo, trim_status, seed = parse_filename(txt.stem)
            times = extract_completion_times(txt)
            if len(times) < min_flows:
                continue
            for t in times:
                records.append({
                    'algorithm': algo,
                    'trim_status': trim_status,
                    'seed': seed,
                    'drop_rate_value': rate,
                    'drop_category': cat,
                    'completion_time': t,
                    'source_file': str(txt.relative_to(root))
                })
    if not records:
        raise RuntimeError("No completion times were parsed. Check folder structure or patterns.")
    return pd.DataFrame.from_records(records)


def make_plot(df: pd.DataFrame, output_path: Path, style: str, palette: str):
    sns.set_style(style)

    # Determine multi-seed mode
    unique_seeds = df['seed'].nunique()
    multi_seed_mode = unique_seeds > 1
    if multi_seed_mode:
        print(f"Detected {unique_seeds} distinct seeds. Aggregating all seeds in violins.")
    else:
        print("Single-seed mode detected.")

    known_df = df[df['trim_status'].isin(['on','off'])]
    if known_df.empty:
        raise RuntimeError("No files with trim_on/trim_off naming found.")

    algorithms = sorted(known_df['algorithm'].unique())
    fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(max(6, 1.3 * len(algorithms)), 9), sharex=True, sharey=True)

    panel_info = [ ('0', 'Drop rate = 0'), ('>0', 'Drop rate > 0') ]
    for ax, (cat, title) in zip(axes, panel_info):
        sub = known_df[known_df['drop_category'] == cat]
        if sub.empty:
            ax.text(0.5, 0.5, f'No data for {title}', ha='center', va='center')
            ax.set_axis_off()
            continue
        # Aggregation over seeds happens implicitly because we do not facet by seed.
        sns.violinplot(
            data=sub,
            x='algorithm',
            y='completion_time',
            hue='trim_status',
            order=algorithms,
            hue_order=['off','on'],
            inner='quartile',
            scale='width',
            cut=0,
            palette=palette,
            ax=ax
        )
        ax.set_title(title + (" (all seeds)" if multi_seed_mode else ""))
        ax.set_xlabel('')
        ax.set_ylabel('Flow Completion Time')
        ax.legend(title='Trim', loc='best')

    axes[-1].set_xlabel('Algorithm')
    plt.tight_layout()
    plt.savefig(output_path)
    print(f"Saved plot to {output_path}")
    plt.show()


def main():
    args = parse_args()
    df = collect_data(args.experiment_root, args.min_flows)
    if args.csv:
        csv_path = args.experiment_root / args.csv
        df.to_csv(csv_path, index=False)
        print(f"Saved CSV to {csv_path}")
    output_path = args.experiment_root / args.output
    make_plot(df, output_path, args.style, args.palette)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
